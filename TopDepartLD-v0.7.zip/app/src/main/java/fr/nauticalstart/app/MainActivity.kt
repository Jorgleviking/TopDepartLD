package fr.nauticalstart.app

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.*
import java.util.Locale
import kotlin.math.*

data class Geo(val lat: Double, val lon: Double)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var board: NavView
    private lateinit var fused: FusedLocationProviderClient
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        // Android 15/targetSdk 35 can draw behind system bars. Keep the UI
        // inside the usable area so the right-side navigation bar never
        // covers controls on landscape phones.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

        fun label(text: String, size: Float = 15f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(Color.DKGRAY)
                gravity = Gravity.CENTER
                maxLines = 2
                includeFontPadding = true
            }

        // Responsive top bar: weighted cells instead of fixed pixel widths.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }

        fun cell(view: View, weight: Float, margins: Int = 2) {
            top.addView(view, LinearLayout.LayoutParams(0, dp(58), weight).apply {
                leftMargin = dp(margins)
                rightMargin = dp(margins)
            })
        }

        val lineLength = label("LONGUEUR LIGNE\n— m", 16f).apply {
            typeface = Typeface.DEFAULT_BOLD
        }
        cell(lineLength, 1.35f)

        val windBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        windBox.addView(label("VENT", 14f), LinearLayout.LayoutParams(0, -1, 1f))
        val windInput = EditText(this).apply {
            hint = "010"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine()
            textSize = 17f
            gravity = Gravity.CENTER
            selectAllOnFocus = true
            setPadding(dp(4), 0, dp(4), 0)
        }
        windBox.addView(windInput, LinearLayout.LayoutParams(dp(72), dp(52)))
        windBox.addView(label("°", 17f), LinearLayout.LayoutParams(dp(20), -1))
        cell(windBox, 1.25f)

        val timer = label("05:00", 24f).apply {
            setTextColor(Color.RED)
            typeface = Typeface.DEFAULT_BOLD
        }
        cell(timer, 0.9f)

        val speed = label("VITESSE\n— kn", 14f)
        cell(speed, 0.95f)

        val heading = label("CAP\n—°", 14f)
        cell(heading, 0.85f)

        val dtl = label("DTL\n— m\n— L", 14f).apply {
            typeface = Typeface.DEFAULT_BOLD
        }
        cell(dtl, 1.0f)

        // Restart/stop remain available but compact, without stealing width
        // from the information cells.
        val restart = Button(this).apply {
            text = "↻"
            textSize = 20f
            contentDescription = "Redémarrer le compte à rebours"
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
        }
        cell(restart, 0.42f)

        val stop = Button(this).apply {
            text = "■"
            textSize = 15f
            contentDescription = "Arrêter le compte à rebours"
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
        }
        cell(stop, 0.42f)

        root.addView(top, LinearLayout.LayoutParams(-1, dp(66)))

        board = NavView(this) {
            lineLength.text = "LONGUEUR LIGNE\n" + if (it >= 0) "%.0f m".format(it) else "— m"
        }
        board.windProvider = { windInput.text.toString().toDoubleOrNull()?.mod(360.0) ?: 0.0 }
        board.statusProvider = { d, n, col ->
            dtl.text = if (d >= 0) "DTL\n%.1f m\n%.1f L".format(d, d/11.0) else "DTL\n— m\n— L"
            dtl.setTextColor(col)
        }
        board.speedProvider = { s -> speed.text = "VITESSE\n%.1f kn".format(s) }
        board.headingProvider = { h -> heading.text = "CAP\n%03d°".format(((h % 360 + 360) % 360).roundToInt()) }

        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(5))
        }
        fun action(text: String, color: Int, onClick: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                setTextColor(Color.WHITE)
                background = ColorDrawable(color)
                setOnClickListener { onClick() }
                textSize = 14f
                minWidth = 0
                minimumWidth = 0
                maxLines = 1
                setPadding(dp(2), 0, dp(2), 0)
            }
        bottom.addView(action("BOUÉE", Color.rgb(21,101,192)) { board.saveBuoy() },
            LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("COMITÉ", Color.rgb(198,40,40)) { board.saveCommittee() },
            LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("EFFACER", Color.DKGRAY) { board.clearMarks() },
            LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("CENTRER", Color.rgb(46,125,50)) { board.centerOnBoat() },
            LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(68)))

        setContentView(root)

                var remaining = 300
        var running = true
        restart.setOnClickListener { remaining = 300; running = true; timer.text = "05:00" }
        stop.setOnClickListener { running = false }

        val handler = android.os.Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                if (running && remaining > 0) {
                    remaining--
                    val mm = remaining / 60
                    val ss = remaining % 60
                    timer.text = "%02d:%02d".format(mm, ss)
                    when {
                        remaining > 60 && ss == 0 -> speak("$mm minutes")
                        remaining in 10..60 && remaining % 10 == 0 -> speak(
                            if (remaining == 60) "1 minute" else "$remaining secondes"
                        )
                        remaining in 1..9 -> speak("$remaining")
                        remaining == 0 -> speak("Départ")
                    }
                }
                handler.postDelayed(this, 1000)
            }
        }
        handler.postDelayed(tick, 1000)

        fused = LocationServices.getFusedLocationProviderClient(this)
        requestLocation()
    }

    private fun requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 42
            )
            return
        }
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000)
            .setMinUpdateIntervalMillis(500)
            .setMaxUpdateDelayMillis(1500)
            .build()
        fused.requestLocationUpdates(request, object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc ->
                    board.updateLocation(
                        Geo(loc.latitude, loc.longitude),
                        if (loc.hasBearing()) loc.bearing.toDouble() else board.lastHeading,
                        if (loc.hasSpeed()) loc.speed * 1.94384449 else board.lastSpeed
                    )
                }
            }
        }, Looper.getMainLooper())
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        if (r == 42) requestLocation()
    }

    private fun speak(s: String) {
        tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "countdown")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.FRENCH
        }
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}

class NavView(
    context: android.content.Context,
    private val onLineLength: (Double) -> Unit
) : View(context) {

    var windProvider: () -> Double = { 0.0 }
    var statusProvider: (Double, Double, Int) -> Unit = { _,_,_ -> }
    var speedProvider: (Double) -> Unit = {}
    var headingProvider: (Double) -> Unit = {}

    var lastHeading = 0.0
    var lastSpeed = 0.0
    private var boat: Geo? = null
    private val trail = mutableListOf<Geo>()
    private var buoy: Geo? = null
    private var committee: Geo? = null
    private var center: Geo? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private var scale = 1.0

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isFocusable = true
    }

    fun updateLocation(g: Geo, heading: Double, speed: Double) {
        boat = g; lastHeading = heading; lastSpeed = speed
        if (trail.isEmpty() || haversine(trail.last(), g) > 1.5) trail.add(g)
        if (center == null) center = g
        speedProvider(speed); headingProvider(heading)
        invalidate()
    }

    fun saveBuoy() { boat?.let { buoy = it; if (center == null) center = it; invalidate(); reportLine() } }
    fun saveCommittee() { boat?.let { committee = it; if (center == null) center = it; invalidate(); reportLine() } }
    fun clearMarks() { buoy = null; committee = null; invalidate(); reportLine() }
    fun centerOnBoat() { center = boat; invalidate() }

    private fun reportLine() {
        val d = if (buoy != null && committee != null) haversine(buoy!!, committee!!) else -1.0
        onLineLength(d)
    }

    private fun haversine(a: Geo, b: Geo): Double {
        val R = 6371000.0
        val p1 = Math.toRadians(a.lat); val p2 = Math.toRadians(b.lat)
        val dp = Math.toRadians(b.lat-a.lat); val dl = Math.toRadians(b.lon-a.lon)
        val x = sin(dp/2).pow(2) + cos(p1)*cos(p2)*sin(dl/2).pow(2)
        return 2*R*atan2(sqrt(x), sqrt(1-x))
    }

    // Web-Mercator screen coordinates around the chosen center.
    private fun project(g: Geo, c: Geo): PointF {
        val R = 6378137.0
        val x = R * Math.toRadians(g.lon)
        val y = R * ln(tan(Math.PI/4 + Math.toRadians(g.lat)/2))
        val cx = R * Math.toRadians(c.lon)
        val cy = R * ln(tan(Math.PI/4 + Math.toRadians(c.lat)/2))
        val metersPerPixel = 1.0 / max(scale, 0.000001)
        return PointF(
            (width/2f + ((x-cx)/metersPerPixel)).toFloat(),
            (height/2f - ((y-cy)/metersPerPixel)).toFloat()
        )
    }

    private fun bearingPoint(g: Geo, bearingDeg: Double, distanceM: Double): Geo {
        val R = 6371000.0
        val br = Math.toRadians((bearingDeg % 360 + 360) % 360)
        val lat1 = Math.toRadians(g.lat)
        val lon1 = Math.toRadians(g.lon)
        val d = distanceM / R
        val lat2 = asin(sin(lat1)*cos(d) + cos(lat1)*sin(d)*cos(br))
        val lon2 = lon1 + atan2(sin(br)*sin(d)*cos(lat1), cos(d)-sin(lat1)*sin(lat2))
        return Geo(Math.toDegrees(lat2), Math.toDegrees(lon2))
    }

    private fun destinationLine(start: Geo, bearing: Double, length: Double, c: Geo): Path {
        val end = bearingPoint(start, bearing, length)
        val p1 = project(start, c); val p2 = project(end, c)
        return Path().apply { moveTo(p1.x,p1.y); lineTo(p2.x,p2.y) }
    }

    private fun pointLineDistanceAndAlong(boat: Geo, a: Geo, b: Geo, heading: Double): Double {
        // Local tangent plane (east, north), accurate enough for a race-line scale.
        val lat0 = Math.toRadians((a.lat+b.lat+boat.lat)/3.0)
        fun xy(g: Geo): DoubleArray {
            val east = Math.toRadians(g.lon-a.lon)*6371000.0*cos(lat0)
            val north = Math.toRadians(g.lat-a.lat)*6371000.0
            return doubleArrayOf(east,north)
        }
        val p = xy(boat); val q = xy(a); val r = xy(b)
        val dx = r[0]-q[0]; val dy = r[1]-q[1]
        val denom = dx*dx+dy*dy
        if (denom < 1e-6) return -1.0
        val t = ((p[0]-q[0])*dx+(p[1]-q[1])*dy)/denom
        if (t !in 0.0..1.0) return -1.0
        val projx=q[0]+t*dx; val projy=q[1]+t*dy

        // Heading vector: 0=N, 90=E.
        val h=Math.toRadians((heading%360+360)%360)
        val vx=sin(h); val vy=cos(h)
        val ex=projx-p[0]; val ey=projy-p[1]
        val along=ex*vx+ey*vy
        return if (along >= 0) along else -1.0
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.WHITE)
        val c = center ?: boat ?: Geo(0.0,0.0)

        // Subtle Mercator grid.
        paint.style = Paint.Style.STROKE; paint.strokeWidth=1f; paint.color=0x18000000
        val grid=80f
        var x=width/2f % grid
        while(x<width){ canvas.drawLine(x,0f,x,height.toFloat(),paint); x+=grid }
        var y=height/2f % grid
        while(y<height){ canvas.drawLine(0f,y,width.toFloat(),y,paint); y+=grid }

        // Historical GPS trail, deliberately behind everything else.
        if(trail.size>1) {
            paint.color=0x40555555; paint.strokeWidth=5f; paint.style=Paint.Style.STROKE
            val path=Path()
            trail.forEachIndexed { i,g -> val p=project(g,c); if(i==0) path.moveTo(p.x,p.y) else path.lineTo(p.x,p.y) }
            canvas.drawPath(path,paint)
        }

        // Race line.
        if(buoy!=null && committee!=null) {
            val b=project(buoy!!,c); val co=project(committee!!,c)
            paint.color=Color.BLACK; paint.strokeWidth=9f; paint.style=Paint.Style.STROKE
            canvas.drawLine(b.x,b.y,co.x,co.y,paint)

            val wind=windProvider().mod(360.0)
            drawRay(canvas, buoy!!, wind+135, Color.RED, c)
            drawRay(canvas, buoy!!, wind-135, Color.RED, c)
            drawRay(canvas, committee!!, wind+135, Color.rgb(46,125,50), c)
            drawRay(canvas, committee!!, wind-135, Color.rgb(46,125,50), c)
        }

        // Points.
        buoy?.let { drawPoint(canvas, project(it,c), Color.rgb(21,101,192), "BOUÉE") }
        committee?.let { drawPoint(canvas, project(it,c), Color.rgb(198,40,40), "COMITÉ") }

        // Wind arrow: kept as a prominent compass-referenced arrow.
        val wind=windProvider().mod(360.0)
        val wc=PointF(width*0.78f,height*0.48f)
        drawArrow(canvas,wc,wind,95f,Color.rgb(30,100,210),7f)

        // Boat: elongated triangle, pointed along GPS heading.
        boat?.let {
            val p=project(it,c)
            drawBoat(canvas,p,lastHeading)
            val d=if(buoy!=null&&committee!=null) pointLineDistanceAndAlong(it,buoy!!,committee!!,lastHeading) else -1.0
            val lengths=if(d>=0) d/11.0 else -1.0
            val timeToLine=if(d>=0 && lastSpeed>0.3) d/(lastSpeed*0.514444) else Double.POSITIVE_INFINITY
            // No access to timer here; UI layer can be extended to compare prediction.
            val col=if(d>=0) Color.rgb(46,125,50) else Color.DKGRAY
            statusProvider(d,lengths,col)
        }

        // Wind input marker and scale are intentionally unobtrusive.
        paint.style=Paint.Style.FILL; paint.color=Color.DKGRAY; paint.textSize=16f
        canvas.drawText("Vent %.0f°".format(wind), 24f, 30f, paint)
        canvas.drawText("100 m", width-105f, height-22f, paint)
    }

    private fun drawRay(canvas: Canvas, start: Geo, bearing: Double, color: Int, c: Geo) {
        paint.color=color; paint.strokeWidth=4f; paint.style=Paint.Style.STROKE
        paint.pathEffect=DashPathEffect(floatArrayOf(16f,12f),0f)
        canvas.drawPath(destinationLine(start,bearing,3000.0,c),paint)
        paint.pathEffect=null
    }

    private fun drawPoint(canvas: Canvas,p:PointF,color:Int,text:String){
        paint.style=Paint.Style.FILL; paint.color=color; canvas.drawCircle(p.x,p.y,14f,paint)
        paint.color=Color.DKGRAY; paint.textSize=18f; canvas.drawText(text,p.x+20,p.y+6,paint)
    }

    private fun drawArrow(canvas:Canvas, center:PointF,bearing:Double,len:Float,color:Int,width:Float){
        val a=Math.toRadians(bearing)
        val ex=center.x+sin(a)*len
        val ey=center.y-cos(a)*len
        paint.color=color; paint.strokeWidth=width; paint.style=Paint.Style.STROKE
        canvas.drawLine(center.x,center.y,ex,ey,paint)
        val left=Math.toRadians(bearing+150); val right=Math.toRadians(bearing-150)
        canvas.drawLine(ex,ey,ex+sin(left)*24,ey-cos(left)*24,paint)
        canvas.drawLine(ex,ey,ex+sin(right)*24,ey-cos(right)*24,paint)
        paint.style=Paint.Style.FILL; canvas.drawCircle(center.x,center.y,7f,paint)
    }

    private fun drawBoat(canvas:Canvas,p:PointF,bearing:Double){
        val a=Math.toRadians(bearing)
        fun rot(x:Float,y:Float):PointF =
            PointF((p.x+x*cos(a).toFloat()+y*sin(a).toFloat()),
                   (p.y-x*sin(a).toFloat()+y*cos(a).toFloat()))
        val tip=rot(34f,0f); val l=rot(-25f,-13f); val r=rot(-25f,13f)
        val path=Path().apply{moveTo(tip.x,tip.y);lineTo(l.x,l.y);lineTo(r.x,r.y);close()}
        paint.style=Paint.Style.FILL; paint.color=Color.BLACK; canvas.drawPath(path,paint)
    }
}
