# TopDepartLD v28

Première base Android en Kotlin.

Fonctions incluses :
- mode paysage forcé ;
- GPS haute précision ;
- canevas sans fond de carte ;
- projection Web/Mercator pour le rendu ;
- trace GPS historique transparente ;
- mémorisation Bouée et Comité ;
- ligne Bouée-Comité épaisse ;
- 4 demi-droites pointillées, orientées par rapport au Nord : vent ±135°, rouges depuis la Bouée et vertes depuis le Comité ;
- flèche de vent visible ;
- bateau simplifié à arrière plat, côtés légèrement arrondis et proue pointue, orienté par le cap GPS ;
- longueur de ligne ;
- DTL en mètres et en longueurs de 11 m ;
- compte à rebours 5:00 ;
- annonces vocales en français aux échéances demandées ;
- boutons Bouée, Comité, Effacer Bouée, Effacer Comité, Centrer ;
- zoom + / − et zoom par pincement ;
- flèche du vent orientée dans le sens où le vent souffle (opposé à la direction saisie « d’où vient le vent ») ;
- compte à rebours avec START / STOP / RESET / SYNC en colonne verticale à droite, avec 05:00 bien visible ;
- TTL (temps à la ligne) visible à côté du DTL.

À compléter dans la prochaine itération :
- comparaison DTL / temps restant avec couleur rouge-jaune-verte synchronisée avec le compte à rebours ;
- persistance éventuelle des marques ;
- réglage de longueur des demi-droites et de l'échelle du canevas ;
- test terrain et ajustement UX.


## v16 — nouvelle interface
- barre supérieure en vraies cases visuelles : LONGUEUR LIGNE / DIRECTION VENT / VITESSE-CAP / DTL ;
- valeurs centrées et largeur adaptative ;
- aucun chevauchement sur les écrans paysage ;
- dimensions UI exprimées en dp ;
- prise en compte des barres système Android en paysage ;
- boutons inférieurs adaptatifs avec libellés visibles ;
- nom/version de l’application incrémentés à TopDepartLD v28.


### v16 — interface
- fond bleu-noir sombre ;
- quadrillage métrique couvrant tout le canevas ;
- le haut de l’écran représente la provenance du vent ;
- la flèche du vent suit toujours le sens réel du vent (direction saisie + 180°) et reste indépendante du quadrillage ;
- le quadrillage est orienté à 45° par rapport à l’axe du vent et remplit tout l’écran, coins compris ;
- bateau représenté à une échelle réelle de 10 m, liée au zoom ;
- barre d’échelle 100 m liée au même facteur d’échelle ;
- compte à rebours agrandi et fortement contrasté ;
- longueur de ligne affichée en petit sur le canevas, sans case dédiée ;
- boutons inférieurs réduits de moitié en hauteur ;
- zone du compte à rebours élargie pour afficher 05:00 en entier.


## v28 — corrections interface et chronomètre
- commandes du compte à rebours en colonne verticale à droite ;
- boutons START / STOP / RESET / SYNC élargis pour rester lisibles ;
- compte à rebours conservé en grand et bien visible ;
- chrono de course démarré automatiquement au top départ et arrêté au franchissement de la ligne ;
- temps réalisé affiché sous le compte à rebours ;
- alarme OCS dans la dernière minute avant le départ.


## v28 — corrections bateau, OCS et largeur des commandes
- bateau orienté exactement selon le cap GPS, avec 0° vers le haut de l’écran ;
- OCS évalué avec la pointe avant du bateau ;
- côté parcours corrigé vers le côté du flux du vent ;
- colonne droite réduite à 155 dp ;
- boutons START / STOP / RESET / SYNC réduits à 88 × 38 dp, sans réduire le compte à rebours.
