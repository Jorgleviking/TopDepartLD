# TopDepartLDtestv2

Projet de test basé sur TopDepartLDtestv1.

- Vue 2D tactique conservée.
- Vue drone tactique améliorée visuellement et volontairement épurée, accessible par le bouton **2D / 3D**.
- Perspective arrière légèrement surélevée, mer sombre, quadrillage discret et ligne de départ néon.
- Ligne de départ, vent, quadrillage, trajectoire et TaL conservés, sans ajouter de nouvelles informations à l’écran.
- Chronomètre de course et temps **DÉPART → LIGNE** conservés. La vue 2D reste inchangée.
