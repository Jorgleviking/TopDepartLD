package fr.nauticalstart.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.content.pm.PackageManager
import android.graphics.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.*
import java.util.Locale
import kotlin.math.*

data class Geo(val lat: Double, val lon: Double)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var board: NavView
    private lateinit var fused: FusedLocationProviderClient
    private var tts: TextToSpeech? = null
    private var ocsAlarmActive = false
    private lateinit var ocsLabel: TextView
    private var toneGenerator: ToneGenerator? = null
    private var raceActive = false
    private var raceFinished = false
    private var raceStartElapsed = 0L
    private var raceTicker: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        tts = TextToSpeech(this, this)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(7, 20, 29))
        }

        // Android 15/targetSdk 35 can draw behind system bars. Keep the UI
        // inside the usable area so the right-side navigation bar never
        // covers controls on landscape phones.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

        fun label(text: String, size: Float = 15f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(Color.DKGRAY)
                gravity = Gravity.CENTER
                maxLines = 2
                includeFontPadding = true
            }

        // v0.8 — barre supérieure dessinée comme une vraie rangée de cases.
        // Chaque case prend une largeur proportionnelle : aucun texte ne peut
        // déborder ou se superposer, même sur un téléphone différent.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            setPadding(dp(4), 0, dp(4), 0)
        }

        fun boxBackground(): android.graphics.drawable.GradientDrawable =
            android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(10, 25, 35))
                setStroke(dp(1), Color.rgb(55, 70, 78))
                cornerRadius = dp(5).toFloat()
            }

        fun valueLabel(text: String, size: Float = 17f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(Color.rgb(235, 240, 243))
                gravity = Gravity.CENTER
                maxLines = 1
                includeFontPadding = false
                typeface = Typeface.DEFAULT_BOLD
                ellipsize = android.text.TextUtils.TruncateAt.END
            }

        fun titleLabel(text: String): TextView =
            TextView(this).apply {
                this.text = text
                textSize = 12f
                setTextColor(Color.rgb(190, 202, 208))
                gravity = Gravity.CENTER
                maxLines = 1
                includeFontPadding = false
                typeface = Typeface.DEFAULT
            }

        fun makeCell(weight: Float, content: View): View {
            val frame = FrameLayout(this).apply {
                background = boxBackground()
                addView(content, FrameLayout.LayoutParams(-1, -1))
            }
            top.addView(frame, LinearLayout.LayoutParams(0, dp(54), weight).apply {
                leftMargin = dp(1)
                rightMargin = dp(1)
            })
            return frame
        }

        fun makeStack(title: String, value: String): LinearLayout =
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(2), dp(3), dp(2))
                addView(titleLabel(title), LinearLayout.LayoutParams(-1, 0, 0.8f))
                addView(valueLabel(value), LinearLayout.LayoutParams(-1, 0, 1.2f))
            }

        val windInput = EditText(this).apply {
            hint = "000"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            textSize = 18f
            gravity = Gravity.CENTER
            setOnFocusChangeListener { v, hasFocus -> if (hasFocus) (v as EditText).selectAll() }
            setTextColor(Color.rgb(240, 245, 247))
            setHintTextColor(Color.rgb(110, 125, 132))
            setPadding(0, 0, 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
        }
        val windCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), 0, dp(2), 0)
            addView(titleLabel("DIRECTION VENT"), LinearLayout.LayoutParams(-1, 0, 0.65f))
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.addView(windInput, LinearLayout.LayoutParams(dp(78), -1))
            row.addView(valueLabel("°", 18f), LinearLayout.LayoutParams(dp(22), -1))
            addView(row, LinearLayout.LayoutParams(-1, 0, 1.35f))
        }
        makeCell(1.00f, windCell)

        val speed = valueLabel("— kn", 16f)
        val heading = valueLabel("—°", 16f)
        val speedHeadingCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), 0, dp(2), 0)
            addView(titleLabel("VITESSE / CAP"), LinearLayout.LayoutParams(-1, 0, 0.65f))
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                addView(speed, LinearLayout.LayoutParams(0, -1, 1f))
                addView(valueLabel("  |  ", 13f), LinearLayout.LayoutParams(dp(34), -1))
                addView(heading, LinearLayout.LayoutParams(0, -1, 1f))
            }
            addView(row, LinearLayout.LayoutParams(-1, 0, 1.35f))
        }
        makeCell(1.10f, speedHeadingCell)

        // Compte à rebours / temps de course intégré au milieu de la ligne supérieure.
        val timerModeLabel = titleLabel("").apply {
            textSize = 12f
            setTextColor(Color.rgb(190, 200, 205))
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        val timer = valueLabel("05:00", 34f).apply {
            setTextColor(Color.RED)
            gravity = Gravity.CENTER
            ellipsize = null
            includeFontPadding = false
        }
        val timerDisplay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = boxBackground()
            setPadding(dp(2), 0, dp(2), 0)
            addView(timerModeLabel, LinearLayout.LayoutParams(-1, 0, 0.48f))
            addView(timer, LinearLayout.LayoutParams(-1, 0, 1.52f))
        }
        top.addView(timerDisplay, LinearLayout.LayoutParams(dp(170), dp(54)).apply {
            leftMargin = dp(1); rightMargin = dp(1)
        })

        ocsLabel = TextView(this).apply {
            text = "OCS"
            textSize = 34f
            setTextColor(Color.RED)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            visibility = View.GONE
            includeFontPadding = false
        }

        val dtl = valueLabel("— m  /  — L", 15f).apply {
            typeface = Typeface.DEFAULT_BOLD
        }
        val dtlCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), 0, dp(2), 0)
            addView(titleLabel("LaL"), LinearLayout.LayoutParams(-1, 0, 0.65f))
            addView(dtl, LinearLayout.LayoutParams(-1, 0, 1.35f))
        }
        makeCell(0.90f, dtlCell)

        // Temps à la ligne + compte à rebours séparés des commandes.
        val timeToLine = valueLabel("— s", 18f).apply {
            setTextColor(Color.rgb(235, 240, 243))
        }
        val timeCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), 0, dp(2), 0)
            addView(titleLabel("TaL"), LinearLayout.LayoutParams(-1, 0, 0.65f))
            addView(timeToLine, LinearLayout.LayoutParams(-1, 0, 1.35f))
        }
        val talCell = makeCell(0.85f, timeCell)

        // Chrono départ → ligne : affiché dès le départ et figé au franchissement.
        val lineElapsed = valueLabel("—", 16f).apply {
            setTextColor(Color.rgb(235, 240, 243))
        }
        val lineElapsedCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = boxBackground()
            addView(titleLabel("DÉPART → LIGNE"), LinearLayout.LayoutParams(-1, 0, 0.65f))
            addView(lineElapsed, LinearLayout.LayoutParams(-1, 0, 1.35f))
            visibility = View.GONE
        }

        // Chrono de course : démarre au départ et continue jusqu’à la touche Arrivée.
        // Son affichage est désormais directement dans la case centrale du compte à rebours.
        val raceTime = valueLabel("00:00.0", 22f).apply {
            setTextColor(Color.rgb(50, 220, 70))
        }

        fun timerButton(textValue: String, bg: Int, size: Float, description: String): Button = Button(this).apply {
            text = textValue
            textSize = size
            setTextColor(Color.WHITE)
            background = ColorDrawable(bg)
            contentDescription = description
            minWidth = 0; minimumWidth = 0
            setPadding(0, 0, 0, 0)
            includeFontPadding = false
            isAllCaps = false
        }
        val start = timerButton("▶", Color.rgb(20, 115, 30), 17f, "Démarrer le compte à rebours")
        val stop = timerButton("■", Color.rgb(190, 35, 35), 17f, "Arrêter le compte à rebours")
        val reset = timerButton("↻", Color.rgb(45, 55, 62), 18f, "Réinitialiser le compte à rebours à 05:00")
        val sync = timerButton("◉", Color.rgb(28, 45, 55), 17f, "Synchroniser le compte à rebours à la demi-minute la plus proche")
        val arrival = timerButton("⚑", Color.rgb(35, 95, 145), 18f, "Arrivée : arrêter le chronomètre de course")

        // Commandes du compte à rebours en colonne à droite : elles ne recouvrent
        // plus la boîte d'information de la ligne en bas.
        val controlsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, 0)
            background = null
        }
        fun verticalTimerButton(button: Button): LinearLayout.LayoutParams =
            LinearLayout.LayoutParams(dp(42), dp(42)).apply {
                topMargin = dp(2)
                bottomMargin = dp(2)
            }
        controlsPanel.addView(start, verticalTimerButton(start))
        controlsPanel.addView(stop, verticalTimerButton(stop))
        controlsPanel.addView(reset, verticalTimerButton(reset))
        controlsPanel.addView(sync, verticalTimerButton(sync))
        controlsPanel.addView(arrival, verticalTimerButton(arrival))

        val menuButton = timerButton("☰", Color.rgb(28, 45, 55), 20f, "Réglages")

        // Zone principale : la carte occupe désormais tout l'écran.
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
        }
        main.addView(top, LinearLayout.LayoutParams(-1, dp(60)))

        var lineCapText: TextView? = null
        var lineLengthText: TextView? = null
        board = NavView(this) { cap, length ->
            lineCapText?.text = if (cap >= 0) "%03d°".format(cap.roundToInt()) else "—°"
            lineLengthText?.text = if (length >= 0) "%.0f m".format(length) else "— m"
        }
        board.raceActiveProvider = { raceActive }
        board.raceStartElapsedProvider = { raceStartElapsed }
        var lineCrossed = false
        board.onLineCrossed = { elapsedMs ->
            if (!lineCrossed && raceActive) {
                lineCrossed = true
                lineElapsed.text = formatRaceTime(elapsedMs)
                lineElapsedCell.visibility = View.VISIBLE
            }
        }
        board.windProvider = { windInput.text.toString().toDoubleOrNull()?.mod(360.0) ?: 0.0 }
        board.statusProvider = { d, n, col ->
            dtl.text = if (d >= 0) "%.1f m / %.1f L".format(d, d / 11.0) else "— m / — L"
            dtl.setTextColor(Color.rgb(235, 240, 243))
            val seconds = if (d >= 0 && board.lastSpeed > 0.3) (d / (board.lastSpeed * 0.514444)).roundToInt() else -1
            timeToLine.text = if (seconds >= 0) "${seconds} s" else "— s"
            val delta = if (seconds >= 0) seconds - board.countdownSeconds else Int.MIN_VALUE
            val talColor = when {
                seconds < 0 -> Color.rgb(235, 240, 243)
                seconds < board.countdownSeconds -> Color.RED
                delta <= 2 -> Color.rgb(255, 190, 0)
                else -> Color.rgb(50, 220, 70)
            }
            timeToLine.setTextColor(talColor)
            // Le compte à rebours reprend exactement le code couleur du TaL.
            // Après le départ, le temps de course reste vert/blanc et n'est plus
            // lié au TaL.
            if (!raceActive) timer.setTextColor(talColor)
        }
        board.speedProvider = { s -> speed.text = "%.1f kn".format(s) }
        board.headingProvider = { h -> heading.text = "%03d°".format(((h % 360 + 360) % 360).roundToInt()) }
        board.ocsProvider = { active ->
            if (active && !ocsAlarmActive) {
                ocsAlarmActive = true
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 700)
                speak("OCS")
            } else if (!active) {
                ocsAlarmActive = false
            }
            ocsLabel.visibility = if (active) View.VISIBLE else View.GONE
            ocsLabel.clearAnimation()
            if (active) {
                val blink = android.view.animation.AlphaAnimation(1f, 0.15f).apply {
                    duration = 450
                    repeatMode = android.view.animation.Animation.REVERSE
                    repeatCount = android.view.animation.Animation.INFINITE
                }
                ocsLabel.startAnimation(blink)
            }
        }

        main.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        fun action(text: String, color: Int, textSizeSp: Float, onClick: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                setTextColor(Color.WHITE)
                background = ColorDrawable(color)
                setOnClickListener { onClick() }
                textSize = textSizeSp
                minWidth = 0; minimumWidth = 0
                maxLines = 1
                isAllCaps = false
                setPadding(dp(1), 0, dp(1), 0)
                includeFontPadding = false
            }
        bottom.addView(action("BOUÉE", Color.rgb(21,101,192), 13f) { board.saveBuoy() },
            LinearLayout.LayoutParams(0, dp(35), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("COMITÉ", Color.rgb(198,40,40), 13f) { board.saveCommittee() },
            LinearLayout.LayoutParams(0, dp(35), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })

        val lineCell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(10, 25, 35))
                setStroke(dp(1), Color.rgb(57, 255, 20))
                cornerRadius = dp(5).toFloat()
            }
            setPadding(dp(5), 0, dp(5), 0)
        }
        val lineTitle = titleLabel("LIGNE").apply {
            setTextColor(Color.rgb(57,255,20))
            typeface = Typeface.DEFAULT_BOLD
        }
        lineCapText = valueLabel("—°", 16f)
        lineLengthText = valueLabel("— m", 16f)
        val capBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(lineCapText, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(titleLabel("Cap Comité → Bouée"), LinearLayout.LayoutParams(-1, 0, 0.75f))
        }
        val lengthBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(lineLengthText, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(titleLabel("Longueur"), LinearLayout.LayoutParams(-1, 0, 0.75f))
        }
        lineCell.addView(capBlock, LinearLayout.LayoutParams(0, -1, 1f))
        lineCell.addView(valueLabel("|", 13f), LinearLayout.LayoutParams(dp(18), -1))
        lineCell.addView(lengthBlock, LinearLayout.LayoutParams(0, -1, 1f))
        val lineFrame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(lineTitle, LinearLayout.LayoutParams(-1, 0, 0.7f))
            addView(lineCell, LinearLayout.LayoutParams(-1, 0, 1.65f))
        }
        bottom.addView(lineFrame, LinearLayout.LayoutParams(0, dp(43), 1.45f).apply {
            leftMargin = dp(2); rightMargin = dp(2)
        })
        // Le bas laisse une petite marge à droite réservée à la colonne de commandes.
        main.addView(bottom, LinearLayout.LayoutParams(-1, dp(49)).apply {
            rightMargin = dp(126)
        })
        root.addView(main, FrameLayout.LayoutParams(-1, -1))
        root.post {
            val lp = FrameLayout.LayoutParams(talCell.width, dp(54))
            lp.leftMargin = talCell.left
            lp.topMargin = top.bottom + dp(2)
            root.addView(lineElapsedCell, lp)
        }
        root.addView(ocsLabel, FrameLayout.LayoutParams(dp(180), dp(48), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(57)
        })

        // Petite colonne fixe à droite, suffisamment étroite pour laisser la carte
        // et les informations de ligne entièrement visibles.
        root.addView(controlsPanel, FrameLayout.LayoutParams(dp(42), dp(226), Gravity.BOTTOM or Gravity.RIGHT).apply {
            rightMargin = dp(10); bottomMargin = dp(10)
        })
        // Le temps de course est désormais affiché dans la case centrale du
        // compte à rebours après le départ. Il n'occupe donc plus d'espace à droite.
        // Menu juste au-dessus de START.
        root.addView(menuButton, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.BOTTOM or Gravity.RIGHT).apply {
            rightMargin = dp(10); bottomMargin = dp(240)
        })

        setContentView(root)

        var remaining = 300
        var running = false
        timerModeLabel.text = "COMPTE À REBOURS"
        var boatLengthMeters = 12.0
        val handler = android.os.Handler(Looper.getMainLooper())

        fun showSettings() {
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(8), dp(20), dp(4))
            }
            val boatLabel = TextView(this).apply {
                text = "Taille du bateau (m)"
                textSize = 16f
                setTextColor(Color.WHITE)
            }
            val boatInput = EditText(this).apply {
                setText("%.0f".format(boatLengthMeters))
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                setSingleLine(true)
                textSize = 18f
                setTextColor(Color.WHITE)
                selectAll()
            }
            val countdownLabel = TextView(this).apply {
                text = "Compte à rebours (secondes)"
                textSize = 16f
                setTextColor(Color.WHITE)
            }
            val countdownInput = EditText(this).apply {
                setText(remaining.toString())
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setSingleLine(true)
                textSize = 18f
                setTextColor(Color.WHITE)
            }
            panel.addView(boatLabel)
            panel.addView(boatInput, LinearLayout.LayoutParams(-1, dp(48)))
            panel.addView(countdownLabel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            panel.addView(countdownInput, LinearLayout.LayoutParams(-1, dp(48)))

            AlertDialog.Builder(this)
                .setTitle("Réglages")
                .setView(panel)
                .setNegativeButton("ANNULER", null)
                .setPositiveButton("OK") { _, _ ->
                    boatInput.text.toString().toDoubleOrNull()?.let {
                        boatLengthMeters = it.coerceIn(5.0, 30.0)
                        board.boatLengthMeters = boatLengthMeters
                    }
                    countdownInput.text.toString().toIntOrNull()?.let {
                        remaining = it.coerceIn(0, 3600)
                        board.countdownSeconds = remaining
                        timer.text = "%02d:%02d".format(remaining / 60, remaining % 60)
                        board.updateOcsState()
                    }
                    board.invalidate()
                }
                .show()
        }
        menuButton.setOnClickListener { showSettings() }
        board.boatLengthMeters = boatLengthMeters
        fun beginRace() {
            if (raceActive) return
            raceActive = true
            raceFinished = false
            lineCrossed = false
            raceStartElapsed = SystemClock.elapsedRealtime()
            raceTime.text = "00:00.0"
            timerModeLabel.text = "TEMPS DE COURSE"
            timer.setTextColor(Color.rgb(50, 220, 70))
            timer.text = "00:00.0"
            lineElapsed.text = "00:00.0"
            lineElapsedCell.visibility = View.VISIBLE
            raceTicker?.let { handler.removeCallbacks(it) }
            val ticker = object : Runnable {
                override fun run() {
                    if (raceActive) {
                        val elapsedNow = SystemClock.elapsedRealtime() - raceStartElapsed
                        val formatted = formatRaceTime(elapsedNow)
                        raceTime.text = formatted
                        timer.text = formatted
                        if (!lineCrossed) lineElapsed.text = formatted
                        handler.postDelayed(this, 100)
                    }
                }
            }
            raceTicker = ticker
            handler.post(ticker)
        }
        start.setOnClickListener {
            if (!running) {
                running = true
                if (remaining == 300) speak("5 minutes")
            }
        }
        stop.setOnClickListener { running = false }
        arrival.setOnClickListener {
            if (raceActive) {
                raceActive = false
                raceFinished = true
                raceTicker?.let { handler.removeCallbacks(it) }
                val finalRaceTime = formatRaceTime(SystemClock.elapsedRealtime() - raceStartElapsed)
                raceTime.text = finalRaceTime
                timer.text = finalRaceTime
            }
        }
        reset.setOnClickListener {
            remaining = 300
            board.countdownSeconds = 300
            running = false
            raceActive = false
            raceFinished = false
            lineCrossed = false
            raceStartElapsed = 0L
            raceTicker?.let { handler.removeCallbacks(it) }
            raceTime.text = "00:00.0"
            timerModeLabel.text = ""
            timer.setTextColor(Color.RED)
            lineElapsed.text = "—"
            lineElapsedCell.visibility = View.GONE
            timer.text = "05:00"
            board.updateOcsState()
            board.invalidate()
        }
        sync.setOnClickListener {
            // Arrondi à la demi-minute la plus proche. Le chronomètre reste dans son état marche/arrêt.
            remaining = ((remaining + 15) / 30) * 30
            board.countdownSeconds = remaining
            timer.text = "%02d:%02d".format(remaining / 60, remaining % 60)
            board.updateOcsState()
            board.invalidate()
        }

        val tick = object : Runnable {
            override fun run() {
                if (running && remaining > 0) {
                    remaining--
                    board.countdownSeconds = remaining
                    val mm = remaining / 60
                    val ss = remaining % 60
                    timer.text = "%02d:%02d".format(mm, ss)
                    board.updateOcsState()
                    when {
                        // Annonce à chaque minute jusqu'à 2 minutes.
                        remaining > 60 && ss == 0 -> speak("$mm minutes")
                        // Dernière minute : annonce toutes les 10 secondes.
                        remaining in 10..60 && remaining % 10 == 0 -> speak(
                            if (remaining == 60) "1 minute" else "$remaining secondes"
                        )
                        remaining == 0 -> {
                            speak("Départ")
                            beginRace()
                        }
                    }
                }
                handler.postDelayed(this, 1000)
            }
        }
        handler.postDelayed(tick, 1000)
        toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)

        fused = LocationServices.getFusedLocationProviderClient(this)
        requestLocation()
    }

    private fun formatRaceTime(elapsedMs: Long): String {
        val tenths = (elapsedMs / 100L) % 10L
        val totalSeconds = elapsedMs / 1000L
        val mm = totalSeconds / 60L
        val ss = totalSeconds % 60L
        return "%02d:%02d.%d".format(mm, ss, tenths)
    }

    private fun requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 42
            )
            return
        }
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000)
            .setMinUpdateIntervalMillis(500)
            .setMaxUpdateDelayMillis(1500)
            .build()
        fused.requestLocationUpdates(request, object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc ->
                    board.updateLocation(
                        Geo(loc.latitude, loc.longitude),
                        if (loc.hasBearing()) loc.bearing.toDouble() else board.lastHeading,
                        if (loc.hasSpeed()) loc.speed * 1.94384449 else board.lastSpeed
                    )
                }
            }
        }, Looper.getMainLooper())
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        if (r == 42) requestLocation()
    }

    private fun speak(s: String) {
        tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "countdown")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.FRENCH
        }
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        toneGenerator?.release(); toneGenerator = null
        super.onDestroy()
    }
}

class NavView(
    context: android.content.Context,
    private val onLineInfo: (Double, Double) -> Unit
) : View(context) {

    var windProvider: () -> Double = { 0.0 }
    var statusProvider: (Double, Double, Int) -> Unit = { _,_,_ -> }
    var speedProvider: (Double) -> Unit = {}
    var headingProvider: (Double) -> Unit = {}
    var ocsProvider: (Boolean) -> Unit = {}
    var raceActiveProvider: () -> Boolean = { false }
    var raceStartElapsedProvider: () -> Long = { 0L }
    var onLineCrossed: (Long) -> Unit = {}

    var lastHeading = 0.0
    var lastSpeed = 0.0
    private var boat: Geo? = null
    private var previousBoat: Geo? = null
    private val trail = mutableListOf<Geo>()
    private var buoy: Geo? = null
    private var committee: Geo? = null
    private var center: Geo? = null
    private var lineLengthMeters: Double = -1.0
    // Current race countdown, in seconds, shared with the TaL color logic.
    var countdownSeconds: Int = 300
    var boatLengthMeters: Double = 12.0

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private var scale = 1.8f // pixels per metre at zoom 1.0

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isFocusable = true
    }

    fun updateLocation(g: Geo, heading: Double, speed: Double) {
        val oldBoat = boat
        if (raceActiveProvider() && oldBoat != null && buoy != null && committee != null) {
            // Le passage de ligne est déclenché par la PRoue du bateau,
            // pas par son centre : c'est bien le côté pointu qui doit franchir
            // la ligne pour arrêter le chrono.
            val oldBow = bearingPoint(oldBoat, lastHeading, 4.0)
            val newBow = bearingPoint(g, heading, 4.0)
            if (crossedStartLine(oldBow, newBow)) {
                onLineCrossed(SystemClock.elapsedRealtime() - raceStartElapsedProvider())
            }
        }
        previousBoat = oldBoat
        boat = g; lastHeading = heading; lastSpeed = speed
        if (trail.isEmpty() || haversine(trail.last(), g) > 1.5) trail.add(g)
        if (center == null) center = g
        speedProvider(speed); headingProvider(heading)
        updateOcsState()
        invalidate()
    }

    fun saveBuoy() { boat?.let { buoy = it; if (center == null) center = it; invalidate(); reportLine() } }
    fun saveCommittee() { boat?.let { committee = it; if (center == null) center = it; invalidate(); reportLine() } }
    fun centerOnBoat() { center = boat; invalidate() }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
                // The zoom buttons are handled on ACTION_UP; don't pan when
                // the gesture starts on one of them.
                panEnabled = !(event.x in 18f..100f && (event.y in 82f..142f || event.y in 147f..207f))
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                pinchStartDistance = distance(event)
                pinchStartScale = scale
                panEnabled = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    val d = distance(event)
                    if (pinchStartDistance > 0f) {
                        scale = (pinchStartScale * (d / pinchStartDistance)).coerceIn(0.45f, 24f)
                        invalidate()
                    }
                } else if (event.pointerCount == 1 && panEnabled) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    panX += dx
                    panY += dy
                    lastTouchX = event.x
                    lastTouchY = event.y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val x = event.x; val y = event.y
                if (x in 18f..100f && y in 82f..142f) {
                    scale = (scale * 1.35f).coerceAtMost(24f)
                    invalidate()
                    return true
                }
                if (x in 18f..100f && y in 147f..207f) {
                    scale = (scale / 1.35f).coerceAtLeast(0.45f)
                    invalidate()
                    return true
                }
                panEnabled = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                panEnabled = false
                return true
            }
        }
        return true
    }

    private var pinchStartDistance = 0f
    private var pinchStartScale = 1.8f
    private var panX = 0f
    private var panY = 0f
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var panEnabled = false

    private fun distance(e: MotionEvent): Float {
        if (e.pointerCount < 2) return 0f
        val dx = e.getX(0) - e.getX(1)
        val dy = e.getY(0) - e.getY(1)
        return hypot(dx, dy)
    }


    private fun crossedStartLine(from: Geo, to: Geo): Boolean {
        val a = committee ?: return false
        val b = buoy ?: return false
        val lat0 = Math.toRadians((a.lat + b.lat + from.lat + to.lat) / 4.0)
        fun xy(g: Geo): Pair<Double, Double> {
            val x = Math.toRadians(g.lon - a.lon) * 6371000.0 * cos(lat0)
            val y = Math.toRadians(g.lat - a.lat) * 6371000.0
            return x to y
        }
        val p = xy(from); val q = xy(to); val r = xy(a); val s = xy(b)
        fun cross(ax: Double, ay: Double, bx: Double, by: Double) = ax * by - ay * bx
        fun orient(p1: Pair<Double,Double>, p2: Pair<Double,Double>, p3: Pair<Double,Double>): Double =
            cross(p2.first-p1.first, p2.second-p1.second, p3.first-p1.first, p3.second-p1.second)
        val o1 = orient(p, q, r); val o2 = orient(p, q, s)
        val o3 = orient(r, s, p); val o4 = orient(r, s, q)
        val eps = 0.05
        return ((o1 > eps && o2 < -eps) || (o1 < -eps && o2 > eps)) &&
               ((o3 > eps && o4 < -eps) || (o3 < -eps && o4 > eps))
    }

    /**
     * OCS : pendant la dernière minute avant le départ, l'alarme se déclenche
     * dès qu'une partie quelconque de la coque passe du côté parcours de la ligne.
     */
    fun updateOcsState() {
        val active = countdownSeconds in 1..60 && boat != null && buoy != null && committee != null && boatHasEnteredCourseSide()
        ocsProvider(active)
    }

    private fun boatHasEnteredCourseSide(): Boolean {
        val b = boat ?: return false
        val a = committee ?: return false
        val z = buoy ?: return false
        val courseSide = courseSideSign(a, z)
        // Le centre et les quatre coins de la coque sont testés. Ainsi, l'alarme
        // retentit dès qu'un morceau du bateau franchit la ligne, et non seulement
        // lorsque la pointe de la proue la franchit.
        val pts = boatHullGeo(b, lastHeading)
        // Le bateau est normalement sous la ligne (côté parcours).
        // OCS uniquement lorsqu'une partie de la coque passe de BAS vers HAUT,
        // donc du côté opposé au côté parcours.
        return pts.any { sideOfLine(a, z, it) * courseSide < 0.0 }
    }

    private fun courseSideSign(a: Geo, z: Geo): Double {
        // La ligne est horizontale à l'écran et le côté parcours est visuellement
        // SOUS la ligne. On calcule donc le signe correspondant au côté BAS,
        // puis l'OCS est déclenché par tout point de coque passé AU-DESSUS.
        val bearingLine = bearingBetween(a, z)
        val displayRotation = (-90.0 - bearingLine)
        val courseBearing = (180.0 - displayRotation + 360.0) % 360.0
        val mid = Geo((a.lat + z.lat) / 2.0, (a.lon + z.lon) / 2.0)
        val probe = bearingPoint(mid, courseBearing, 10.0)
        return if (sideOfLine(a, z, probe) >= 0.0) 1.0 else -1.0
    }

    private fun sideOfLine(a: Geo, z: Geo, p: Geo): Double {
        val lat0 = Math.toRadians((a.lat + z.lat + p.lat) / 3.0)
        val ax = Math.toRadians(a.lon) * 6371000.0 * cos(lat0)
        val ay = Math.toRadians(a.lat) * 6371000.0
        val zx = Math.toRadians(z.lon) * 6371000.0 * cos(lat0)
        val zy = Math.toRadians(z.lat) * 6371000.0
        val px = Math.toRadians(p.lon) * 6371000.0 * cos(lat0)
        val py = Math.toRadians(p.lat) * 6371000.0
        return (zx - ax) * (py - ay) - (zy - ay) * (px - ax)
    }

    private fun boatHullGeo(b: Geo, heading: Double): List<Geo> {
        val halfBow = boatLengthMeters * 0.59
        val halfStern = boatLengthMeters * 0.41
        val halfWidth = boatLengthMeters * 0.168
        return listOf(
            bearingPoint(b, heading, halfBow),
            bearingPoint(bearingPoint(b, heading, -halfStern), (heading + 90.0) % 360.0, halfWidth),
            bearingPoint(bearingPoint(b, heading, -halfStern), (heading - 90.0 + 360.0) % 360.0, halfWidth),
            b
        )
    }

    private fun reportLine() {
        val d = if (buoy != null && committee != null) haversine(buoy!!, committee!!) else -1.0
        lineLengthMeters = d
        val cap = if (buoy != null && committee != null) bearingBetween(committee!!, buoy!!) else -1.0
        onLineInfo(cap, d)
        invalidate()
    }

    private fun haversine(a: Geo, b: Geo): Double {
        val R = 6371000.0
        val p1 = Math.toRadians(a.lat); val p2 = Math.toRadians(b.lat)
        val dp = Math.toRadians(b.lat-a.lat); val dl = Math.toRadians(b.lon-a.lon)
        val x = sin(dp/2).pow(2) + cos(p1)*cos(p2)*sin(dl/2).pow(2)
        return 2*R*atan2(sqrt(x), sqrt(1-x))
    }

    // Cap géographique de la ligne comité -> bouée.
    // Sert uniquement à orienter l'affichage pour que la ligne de départ
    // soit horizontale dès que les deux marques sont enregistrées.
    private fun bearingBetween(a: Geo, b: Geo): Double {
        val lat1 = Math.toRadians(a.lat)
        val lat2 = Math.toRadians(b.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    // Web-Mercator screen coordinates around the chosen center.
    private fun project(g: Geo, c: Geo): PointF {
        val R = 6378137.0
        val x = R * Math.toRadians(g.lon)
        val y = R * ln(tan(Math.PI/4 + Math.toRadians(g.lat)/2))
        val cx = R * Math.toRadians(c.lon)
        val cy = R * ln(tan(Math.PI/4 + Math.toRadians(c.lat)/2))
        val pixelsPerMeter = max(scale, 0.000001f)
        return PointF(
            (width/2f + ((x-cx)*pixelsPerMeter)).toFloat(),
            (height/2f - ((y-cy)*pixelsPerMeter)).toFloat()
        )
    }

    private fun bearingPoint(g: Geo, bearingDeg: Double, distanceM: Double): Geo {
        val R = 6371000.0
        val br = Math.toRadians((bearingDeg % 360 + 360) % 360)
        val lat1 = Math.toRadians(g.lat)
        val lon1 = Math.toRadians(g.lon)
        val d = distanceM / R
        val lat2 = asin(sin(lat1)*cos(d) + cos(lat1)*sin(d)*cos(br))
        val lon2 = lon1 + atan2(sin(br)*sin(d)*cos(lat1), cos(d)-sin(lat1)*sin(lat2))
        return Geo(Math.toDegrees(lat2), Math.toDegrees(lon2))
    }

    private fun destinationLine(start: Geo, bearing: Double, length: Double, c: Geo): Path {
        val end = bearingPoint(start, bearing, length)
        val p1 = project(start, c); val p2 = project(end, c)
        return Path().apply { moveTo(p1.x,p1.y); lineTo(p2.x,p2.y) }
    }

    private fun forwardDistanceToLine(boat: Geo, a: Geo, b: Geo, heading: Double): Double {
        // Local tangent plane (east, north). The ray starts at the supplied
        // point and follows the boat heading. We only return an intersection
        // when it is in front of the boat and lands on the actual start line.
        val lat0 = Math.toRadians((a.lat + b.lat + boat.lat) / 3.0)
        fun xy(g: Geo): DoubleArray {
            val east = Math.toRadians(g.lon - boat.lon) * 6371000.0 * cos(lat0)
            val north = Math.toRadians(g.lat - boat.lat) * 6371000.0
            return doubleArrayOf(east, north)
        }
        val q = xy(a)
        val r = xy(b)
        val hx = sin(Math.toRadians(heading))
        val hy = cos(Math.toRadians(heading))
        val dx = r[0] - q[0]
        val dy = r[1] - q[1]
        val cross = hx * dy - hy * dx
        if (abs(cross) < 1e-9) return -1.0
        val qx = q[0]; val qy = q[1]
        val t = (qx * dy - qy * dx) / cross
        val u = (qx * hy - qy * hx) / cross
        return if (t > 0.0 && u in 0.0..1.0) t else -1.0
    }

    private fun talColor(timeSeconds: Double): Int {
        if (!timeSeconds.isFinite()) return Color.DKGRAY
        val delta = timeSeconds - countdownSeconds
        return when {
            delta < 0.0 -> Color.RED
            delta <= 2.0 -> Color.rgb(255, 190, 0)
            else -> Color.rgb(50, 220, 70)
        }
    }

    private fun drawTalPoint(canvas: Canvas, hit: PointF, timeSeconds: Double, color: Int) {
        // Un seul repère sur la ligne : le point d'intersection de l'axe du
        // bateau avec la ligne de départ. Aucun segment n'est dessiné.
        paint.style = Paint.Style.FILL
        paint.color = Color.BLACK
        canvas.drawCircle(hit.x, hit.y, 8f, paint)
        paint.color = color
        canvas.drawCircle(hit.x, hit.y, 5f, paint)

        // Le TaL est posé juste au-dessus du point et n'affiche que le nombre.
        val label = if (timeSeconds < 100.0) "%.1f".format(timeSeconds) else "%.0f".format(timeSeconds)
        paint.style = Paint.Style.FILL
        // TaL sur la ligne : taille doublée par rapport à la version précédente.
        paint.textSize = 64f
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textAlign = Paint.Align.CENTER
        paint.setShadowLayer(3f, 0f, 0f, Color.BLACK)
        paint.color = color
        canvas.drawText(label, hit.x, hit.y - 11f, paint)
        paint.clearShadowLayer()
        paint.textAlign = Paint.Align.LEFT
        paint.typeface = Typeface.DEFAULT
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(7, 20, 29))
        val c = center ?: boat ?: Geo(0.0,0.0)
        val windFrom = windProvider().mod(360.0)
        // Avant le placement des deux marques, l'affichage reste référencé
        // par le vent. Dès que comité + bouée sont présents, la ligne de départ
        // devient la nouvelle référence visuelle et est automatiquement
        // horizontale à l'écran.
        //
        // En coordonnées écran (Est = +X, Nord = -Y), une rotation de
        // -90° - bearing rend la ligne horizontale avec le COMITÉ à droite
        // et la BOUÉE à gauche.
        val displayRotation = if (buoy != null && committee != null) {
            (-90.0 - bearingBetween(committee!!, buoy!!)).toFloat()
        } else {
            (-windFrom).toFloat()
        }

        canvas.save()
        canvas.rotate(displayRotation, width / 2f, height / 2f)
        canvas.translate(panX, panY)

        // Le quadrillage reste volontairement incliné de 45° par rapport
        // à la référence active de l'affichage, et remplit largement les
        // quatre coins afin qu'aucune zone vide n'apparaisse après rotation.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = Color.rgb(42, 62, 72)
        // La taille saisie dans le menu définit aussi l'espacement du quadrillage :
        // un carreau représente exactement une longueur de bateau.
        val grid = (boatLengthMeters * scale).toFloat().coerceAtLeast(1f)
        val diagonal = hypot(width.toFloat(), height.toFloat()) + grid * 2f

        canvas.save()
        canvas.rotate(45f, width / 2f, height / 2f)
        var x = -diagonal
        while (x <= diagonal) {
            canvas.drawLine(x, -diagonal, x, diagonal, paint)
            x += grid
        }
        var y = -diagonal
        while (y <= diagonal) {
            canvas.drawLine(-diagonal, y, diagonal, y, paint)
            y += grid
        }
        canvas.restore()

        // Historical GPS trail, deliberately behind everything else.
        if(trail.size>1) {
            paint.color=0x40555555; paint.strokeWidth=5f; paint.style=Paint.Style.STROKE
            val path=Path()
            trail.forEachIndexed { i,g -> val p=project(g,c); if(i==0) path.moveTo(p.x,p.y) else path.lineTo(p.x,p.y) }
            canvas.drawPath(path,paint)
        }

        // La ligne comité-bouée est maintenant horizontale à l'écran dès que
        // les deux marques sont sélectionnées. Les laylines restent calculées
        // à partir de la direction du vent.
        if(buoy!=null && committee!=null) {
            val b=project(buoy!!,c); val co=project(committee!!,c)
            // High-visibility race start line: dark outline + fluorescent green core.
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 11f
            paint.color = Color.BLACK
            paint.pathEffect = null
            canvas.drawLine(b.x, b.y, co.x, co.y, paint)
            paint.strokeWidth = 7f
            paint.color = Color.rgb(57, 255, 20) // fluorescent green
            canvas.drawLine(b.x, b.y, co.x, co.y, paint)

            drawRay(canvas, buoy!!, windFrom+135, Color.RED, c)
            drawRay(canvas, buoy!!, windFrom-135, Color.RED, c)
            drawRay(canvas, committee!!, windFrom+135, Color.rgb(46,125,50), c)
            drawRay(canvas, committee!!, windFrom-135, Color.rgb(46,125,50), c)
        }

        // Points.
        buoy?.let { drawPoint(canvas, project(it,c), Color.rgb(21,101,192), "BOUÉE") }
        committee?.let { drawPoint(canvas, project(it,c), Color.rgb(198,40,40), "COMITÉ") }

        // Boat: elongated triangle, pointed along GPS heading.
        boat?.let {
            val p=project(it,c)
            // Le TaL est matérialisé uniquement par un point sur la ligne,
            // à l'intersection de l'axe de déplacement avec la ligne de départ.
            // Il disparaît si cette intersection est absente ou derrière le bateau.
            val bowGeo = bearingPoint(it, lastHeading, boatLengthMeters * 0.59)
            val d=if(buoy!=null&&committee!=null) forwardDistanceToLine(bowGeo,buoy!!,committee!!,lastHeading) else -1.0
            val lengths=if(d>=0) d/11.0 else -1.0
            val timeToLine=if(d>=0 && lastSpeed>0.3) d/(lastSpeed*0.514444) else Double.POSITIVE_INFINITY
            if (d > 0.0 && timeToLine.isFinite()) {
                val hitGeo = bearingPoint(bowGeo, lastHeading, d)
                val hit = project(hitGeo, c)
                drawTalPoint(canvas, hit = hit, timeSeconds = timeToLine, color = talColor(timeToLine))
            }
            drawBoat(canvas,p,lastHeading)
            statusProvider(d,lengths,talColor(timeToLine))
        }

        canvas.restore()

        // Flèche du vent : la valeur saisie est la direction D'OÙ VIENT
        // le vent. La flèche indique donc OÙ IL SOUFFLE (+180°), en tenant
        // compte de la rotation actuelle de la carte.
        val windScreenBearing = windFrom + 180.0 + displayRotation
        val wc = PointF(width / 2f, 52f)
        drawArrow(canvas, wc, windScreenBearing, 104f, Color.WHITE, 5f)

        // Nord vrai : indépendant du vent et du cap du bateau. La flèche
        // suit l'orientation de la carte et indique toujours le nord
        // géographique à l'écran.
        paint.style=Paint.Style.FILL; paint.color=Color.rgb(235,240,243); paint.textSize=16f
        canvas.drawText("N", 47f, 24f, paint)
        drawArrow(canvas, PointF(52f, 52f), displayRotation.toDouble(), 30f, Color.WHITE, 3f)

        // Metric scale bar: always represents exactly 100 real metres.
        val barPx = (100f * scale).coerceIn(80f, width * 0.28f)
        paint.color=Color.rgb(230,235,238); paint.strokeWidth=2f; paint.style=Paint.Style.STROKE
        canvas.drawLine(width-barPx-28f, height-32f, width-28f, height-32f, paint)
        canvas.drawLine(width-barPx-28f, height-38f, width-barPx-28f, height-26f, paint)
        canvas.drawLine(width-28f, height-38f, width-28f, height-26f, paint)
        paint.style=Paint.Style.FILL; paint.textSize=14f
        canvas.drawText("100 m", width-barPx/2f-20f, height-44f, paint)

        // Boutons de zoom + / −
        paint.style = Paint.Style.FILL; paint.color = Color.rgb(12, 29, 39)
        canvas.drawRoundRect(18f, 82f, 100f, 142f, 12f, 12f, paint)
        canvas.drawRoundRect(18f, 147f, 100f, 207f, 12f, 12f, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = Color.rgb(70, 90, 100)
        canvas.drawRoundRect(18f, 82f, 100f, 142f, 12f, 12f, paint)
        canvas.drawRoundRect(18f, 147f, 100f, 207f, 12f, 12f, paint)
        paint.style = Paint.Style.FILL; paint.color = Color.WHITE; paint.textSize = 42f
        canvas.drawText("+", 42f, 126f, paint)
        canvas.drawText("−", 43f, 191f, paint)
    }

    private fun drawRay(canvas: Canvas, start: Geo, bearing: Double, color: Int, c: Geo) {
        paint.color=color; paint.strokeWidth=4f; paint.style=Paint.Style.STROKE
        paint.pathEffect=DashPathEffect(floatArrayOf(16f,12f),0f)
        canvas.drawPath(destinationLine(start,bearing,3000.0,c),paint)
        paint.pathEffect=null
    }

    private fun drawPoint(canvas: Canvas,p:PointF,color:Int,text:String){
        paint.style=Paint.Style.FILL; paint.color=color; canvas.drawCircle(p.x,p.y,14f,paint)
        paint.color=Color.DKGRAY; paint.textSize=18f; canvas.drawText(text,p.x+20,p.y+6,paint)
    }

    private fun drawArrow(canvas:Canvas, center:PointF,bearing:Double,len:Float,color:Int,width:Float){
        val a=Math.toRadians(bearing)
        val ex=center.x+sin(a)*len
        val ey=center.y-cos(a)*len
        paint.color=color; paint.strokeWidth=width; paint.style=Paint.Style.STROKE
        canvas.drawLine(center.x,center.y,ex.toFloat(),ey.toFloat(),paint)
        val left=Math.toRadians(bearing+150); val right=Math.toRadians(bearing-150)
        canvas.drawLine(ex.toFloat(),ey.toFloat(),(ex+sin(left)*24).toFloat(),(ey-cos(left)*24).toFloat(),paint)
        canvas.drawLine(ex.toFloat(),ey.toFloat(),(ex+sin(right)*24).toFloat(),(ey-cos(right)*24).toFloat(),paint)
        paint.style=Paint.Style.FILL; canvas.drawCircle(center.x,center.y,7f,paint)
    }

    private fun drawBoat(canvas:Canvas,p:PointF,bearing:Double){
        // Bateau simplifié : arrière plat, côtés légèrement arrondis,
        // proue pointue.  L'axe longitudinal suit exactement le cap GPS:
        // 0° = vers le haut de l'écran, 90° = vers la droite.
        val a=Math.toRadians(bearing)
        // La taille du bateau réglée dans le menu pilote directement son dessin.
        // On conserve les proportions du visuel précédent (12 m de référence).
        val sizeFactor = (boatLengthMeters / 12.0).toFloat()
        val L = 7.0f * scale * sizeFactor
        val W = 2.0f * scale * sizeFactor
        fun rot(forward:Float, lateral:Float):PointF = PointF(
            p.x + forward * sin(a).toFloat() + lateral * cos(a).toFloat(),
            p.y - forward * cos(a).toFloat() + lateral * sin(a).toFloat()
        )
        val bow=rot(L,0f)
        val sternL=rot(-L*0.70f,-W)
        val sternR=rot(-L*0.70f,W)
        val sideL=rot(-L*0.28f,-W*1.02f)
        val sideR=rot(-L*0.28f,W*1.02f)
        val hull=Path().apply {
            moveTo(bow.x,bow.y)
            quadTo(sideL.x,sideL.y,sternL.x,sternL.y)
            lineTo(sternR.x,sternR.y)
            quadTo(sideR.x,sideR.y,bow.x,bow.y)
            close()
        }
        paint.style=Paint.Style.FILL
        paint.color=Color.rgb(235,240,243)
        canvas.drawPath(hull,paint)
        paint.style=Paint.Style.STROKE
        paint.strokeWidth=max(1.8f,scale*0.20f)
        paint.color=Color.rgb(25,35,43)
        canvas.drawPath(hull,paint)
        val inset=Path().apply {
            val ib=rot(L*0.72f,0f)
            val il=rot(-L*0.52f,-W*0.62f)
            val ir=rot(-L*0.52f,W*0.62f)
            moveTo(ib.x,ib.y); lineTo(il.x,il.y); lineTo(ir.x,ir.y); close()
        }
        paint.style=Paint.Style.FILL
        paint.color=Color.rgb(220,45,45)
        canvas.drawPath(inset,paint)
    }
}