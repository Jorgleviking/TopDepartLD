# Nautical Start v0.2

Version préparée pour compilation Android.

Fonctions :
- paysage, canevas sans fond de carte ;
- Web Mercator pour la représentation ;
- GPS haute précision ;
- trace GPS passée translucide, derrière les autres éléments ;
- triangle allongé pour le bateau, orienté selon le cap GPS ;
- boutons BOUÉE / COMITÉ / EFFACER / CENTRER ;
- ligne Bouée-Comité noire, épaisse et prioritaire ;
- longueur de ligne en mètres ;
- vent en degrés, avec grosse flèche : 0° = Nord, 90° = Est ;
- depuis chaque point : demi-droites pointillées, rouges à la Bouée et vertes au Comité, aux directions vent +135° et vent -135°, calculées par rapport au Nord ;
- DTL = distance en mètres depuis le bateau jusqu'à la ligne, mesurée dans le cap du bateau et uniquement si le rayon avant intersecte le segment Bouée-Comité ;
- conversion DTL / 11 m en longueurs ;
- couleur DTL : rouge si intersection avant la fin du compte à rebours, jaune jusqu'à 2 s après, vert au-delà de 2 s ;
- compte à rebours 5:00, affichage chaque seconde ;
- annonces vocales : chaque minute, puis toutes les 10 s dans la dernière minute, puis chaque seconde dans les 10 dernières secondes, puis « Départ » ;
- aucune légende ni bouton son.

Le workflow GitHub Actions produit un APK debug automatiquement.
