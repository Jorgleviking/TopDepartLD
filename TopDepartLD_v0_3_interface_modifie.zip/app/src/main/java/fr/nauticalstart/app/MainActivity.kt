package fr.nauticalstart.app

import android.Manifest
import android.app.Activity
import android.os.*
import android.speech.tts.TextToSpeech
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import java.util.Locale
import kotlin.math.*

data class Geo(val lat: Double, val lon: Double)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var nav: NavView
    private lateinit var timerView: TextView
    private lateinit var dtlView: TextView
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var remaining = 300
    private var running = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        tts = TextToSpeech(this, this)

        fun dp(v: Float): Int = (v * resources.displayMetrics.density).roundToInt()
        fun tv(text: String, size: Float, color: Int = Color.DKGRAY) = TextView(this).apply {
            this.text = text
            textSize = size
            gravity = Gravity.CENTER
            setTextColor(color)
            typeface = Typeface.DEFAULT_BOLD
        }
        fun card(title: String, value: String, accent: Int): LinearLayout {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(5f), dp(5f), dp(5f), dp(5f))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE)
                    setStroke(dp(1.2f), Color.rgb(190, 195, 200))
                    cornerRadius = dp(10f).toFloat()
                }
            }
            box.addView(tv(title, 12f, Color.WHITE), LinearLayout.LayoutParams(-1, 0, 0.32f))
            box.addView(tv(value, 25f, accent), LinearLayout.LayoutParams(-1, 0, 0.68f))
            return box
        }
        fun button(text: String, accent: Int, action: () -> Unit) = Button(this).apply {
            this.text = text
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
            isAllCaps = false
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                setStroke(dp(1.5f), accent)
                cornerRadius = dp(10f).toFloat()
            }
            setOnClickListener { action() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(8f), dp(7f), dp(8f), dp(7f))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val lineView = tv("—\nm", 24f, Color.DKGRAY)
        val windInput = EditText(this).apply {
            setText("010")
            textSize = 22f
            gravity = Gravity.CENTER
            setSingleLine()
            setTextColor(Color.rgb(30, 110, 200))
            setHintTextColor(Color.rgb(30, 110, 200))
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            background = null
            setPadding(0, 0, 0, 0)
        }
        val dtlView = tv("— L", 25f, Color.rgb(95, 160, 45))
        timerView = tv("05:00", 25f, Color.rgb(210, 40, 40))
        val headingView = tv("—°", 25f, Color.DKGRAY)
        val speedView = tv("—", 25f, Color.DKGRAY)
        val cutView = tv("—", 25f, Color.rgb(210, 40, 40))

        fun addCard(title: String, view: View, weight: Float = 1f) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(5f), dp(4f), dp(5f), dp(4f))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE)
                    setStroke(dp(1.2f), Color.rgb(190, 195, 200))
                    cornerRadius = dp(10f).toFloat()
                }
            }
            box.addView(tv(title, 11.5f, Color.WHITE), LinearLayout.LayoutParams(-1, 0, 0.38f))
            box.addView(view, LinearLayout.LayoutParams(-1, 0, 0.62f))
            top.addView(box, LinearLayout.LayoutParams(0, dp(92f), weight).apply { setMargins(dp(2f), 0, dp(2f), 0) })
        }

        addCard("LONGUEUR DE LIGNE", lineView)
        addCard("DIRECTION DU VENT", windInput)
        addCard("DTL", dtlView)
        addCard("COMPTE À REBOURS", timerView)
        addCard("CAP", headingView)
        addCard("VITESSE", speedView)
        addCard("TEMPS À LA LIGNE", cutView)
        root.addView(top, LinearLayout.LayoutParams(-1, dp(100f)))

        nav = NavView(this)
        nav.windProvider = {
            windInput.text.toString().replace("°", "").toDoubleOrNull()?.let { ((it % 360) + 360) % 360 } ?: 0.0
        }
        nav.onLineLength = { d ->
            lineView.text = if (d >= 0) "%.0f m".format(d) else "— m"
        }
        nav.onMetrics = { dtl, speed, heading, color, timeToLine ->
            dtlView.text = if (dtl >= 0) "%.1f L".format(dtl / 11.0) else "— L"
            dtlView.setTextColor(color)
            speedView.text = if (speed >= 0) "%.1f\nnds".format(speed) else "—"
            headingView.text = if (heading.isFinite()) "%03d°".format(((heading % 360 + 360) % 360).roundToInt()) else "—°"
            cutView.text = if (timeToLine.isFinite()) formatSeconds(timeToLine.roundToInt()) else "—"
            cutView.setTextColor(color)
        }
        nav.timerSecondsProvider = { remaining }
        root.addView(nav, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(5f), 0, 0)
        }
        fun addBottom(text: String, accent: Int, action: () -> Unit) {
            bottom.addView(button(text, accent, action), LinearLayout.LayoutParams(0, dp(68f), 1f).apply { setMargins(dp(2f), 0, dp(2f), 0) })
        }
        addBottom("🔵  BOUÉE", Color.rgb(21, 101, 192)) { nav.saveBuoy() }
        addBottom("🔴  COMITÉ", Color.rgb(198, 40, 40)) { nav.saveCommittee() }
        addBottom("⌫  EFFACER BOUÉE", Color.rgb(21, 101, 192)) { nav.clearBuoy() }
        addBottom("⌫  EFFACER COMITÉ", Color.rgb(198, 40, 40)) { nav.clearCommittee() }
        addBottom("🎯  CENTRER SUR LE BATEAU", Color.rgb(30, 100, 210)) { nav.centerOnBoat() }
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(75f)))
        setContentView(root)

        handler.postDelayed(object : Runnable {
            override fun run() {
                if (running && remaining > 0) {
                    remaining--
                    updateTimer()
                    if (remaining > 60 && remaining % 60 == 0) speak(if (remaining / 60 == 1) "1 minute" else "${remaining / 60} minutes")
                    else if (remaining in 10..60 && remaining % 10 == 0) speak(if (remaining == 60) "1 minute" else "$remaining secondes")
                    else if (remaining in 1..9) speak("$remaining")
                    else if (remaining == 0) speak("Départ")
                }
                nav.invalidate()
                handler.postDelayed(this, 1000)
            }
        }, 1000)
        startGps()
    }

    private fun formatSeconds(s: Int): String = "%02d:%02d".format(max(0, s) / 60, max(0, s) % 60)

    private fun showDisplayInfo() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Info d'affichage")
            .setMessage("Affichage : longueur de ligne, vent, DTL, compte à rebours, cap, vitesse et temps avant la ligne.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showMenu() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(arrayOf("Redémarrer le compte à rebours", "Arrêter le compte à rebours")) { _, which ->
                if (which == 0) resetTimer() else running = false
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun updateTimer(){
        timerView.text="%02d:%02d".format(remaining/60,remaining%60)
    }
    private fun resetTimer(){remaining=300;running=true;updateTimer();nav.invalidate()}
    private fun speak(s:String){tts?.speak(s,TextToSpeech.QUEUE_FLUSH,null,"countdown")}
    override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS)tts?.language=Locale.FRENCH}

    private fun startGps(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),42);return
        }
        val client=LocationServices.getFusedLocationProviderClient(this)
        val req=LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000).setMinUpdateIntervalMillis(500).build()
        client.requestLocationUpdates(req,object:LocationCallback(){
            override fun onLocationResult(r:LocationResult){
                r.lastLocation?.let{l->nav.updateLocation(Geo(l.latitude,l.longitude),
                    if(l.hasBearing())l.bearing.toDouble() else nav.heading,
                    if(l.hasSpeed())l.speed*1.94384449 else nav.speed)}
            }
        },Looper.getMainLooper())
    }
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){
        super.onRequestPermissionsResult(r,p,g);if(r==42)startGps()
    }
    override fun onDestroy(){handler.removeCallbacksAndMessages(null);tts?.stop();tts?.shutdown();super.onDestroy()}
}

class NavView(c:android.content.Context):View(c){
    var windProvider:()->Double={0.0}
    var onLineLength:(Double)->Unit={}
    var onMetrics:(Double,Double,Double,Int,Double)->Unit={_,_,_,_,_->}
    var timerSecondsProvider:()->Int={300}

    var boat:Geo?=null; var buoy:Geo?=null; var committee:Geo?=null
    var heading=0.0; var speed=0.0
    private val trail=mutableListOf<Geo>()
    private var center:Geo?=null
    private var zoom = 1f
    private lateinit var scaleDetector: ScaleGestureDetector
    private val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{strokeCap=Paint.Cap.ROUND}

    init {
        scaleDetector = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoom = (zoom * detector.scaleFactor).coerceIn(0.35f, 6.0f)
                invalidate()
                return true
            }
        })
        isFocusable = true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        return true
    }

    fun updateLocation(g:Geo,h:Double,s:Double){
        boat=g;heading=h;speed=s
        if(trail.isEmpty()||distance(trail.last(),g)>1.5)trail.add(g)
        if(center==null)center=g
        invalidate()
    }
    fun saveBuoy(){boat?.let{buoy=it;center=center?:it;report();invalidate()}}
    fun saveCommittee(){boat?.let{committee=it;center=center?:it;report();invalidate()}}
    fun clearBuoy(){buoy=null;report();invalidate()}
    fun clearCommittee(){committee=null;report();invalidate()}
    fun clearMarks(){buoy=null;committee=null;report();invalidate()}
    fun centerOnBoat(){center=boat;invalidate()}
    private fun report(){onLineLength(if(buoy!=null&&committee!=null)distance(buoy!!,committee!!) else -1.0)}

    private fun distance(a:Geo,b:Geo):Double{
        val R=6371000.0;val p1=Math.toRadians(a.lat);val p2=Math.toRadians(b.lat)
        val dp=Math.toRadians(b.lat-a.lat);val dl=Math.toRadians(b.lon-a.lon)
        val q=sin(dp/2).pow(2)+cos(p1)*cos(p2)*sin(dl/2).pow(2)
        return 2*R*atan2(sqrt(q),sqrt(1-q))
    }
    private fun bearingPoint(g:Geo,b:Double,d:Double):Geo{
        val R=6371000.0;val br=Math.toRadians(((b%360)+360)%360);val la=Math.toRadians(g.lat);val lo=Math.toRadians(g.lon);val x=d/R
        val la2=asin(sin(la)*cos(x)+cos(la)*sin(x)*cos(br))
        val lo2=lo+atan2(sin(br)*sin(x)*cos(la),cos(x)-sin(la)*sin(la2))
        return Geo(Math.toDegrees(la2),Math.toDegrees(lo2))
    }
    private fun merc(g:Geo,c:Geo):PointF{
        val R=6378137.0
        fun xy(x:Geo):DoubleArray{
            val X=R*Math.toRadians(x.lon);val Y=R*ln(tan(Math.PI/4+Math.toRadians(x.lat)/2));return doubleArrayOf(X,Y)
        }
        val a=xy(g);val b=xy(c)
        // Adaptive scale: show line and nearby track without background map.
        val mpp=0.65
        return PointF(
            (width/2f+(a[0]-b[0])/mpp*zoom).toFloat(),
            (height/2f-(a[1]-b[1])/mpp*zoom).toFloat()
        )
    }
    private fun rayPath(start:Geo,b:Double,len:Double,c:Geo):Path{
        val e=bearingPoint(start,b,len);val a=merc(start,c);val z=merc(e,c)
        return Path().apply{moveTo(a.x,a.y);lineTo(z.x,z.y)}
    }

    override fun onDraw(c:Canvas){
        super.onDraw(c);c.drawColor(Color.WHITE)
        val ctr=center?:boat?:Geo(0.0,0.0)

        // very subtle plotting grid
        p.style=Paint.Style.STROKE;p.strokeWidth=1f;p.color=0x14000000
        for(x in 0 until width step 90)c.drawLine(x.toFloat(),0f,x.toFloat(),height.toFloat(),p)
        for(y in 0 until height step 90)c.drawLine(0f,y.toFloat(),width.toFloat(),y.toFloat(),p)

        // history behind everything
        if(trail.size>1){
            p.color=0x40505050;p.strokeWidth=4f
            val q=Path()
            trail.forEachIndexed{i,g->val z=merc(g,ctr);if(i==0)q.moveTo(z.x,z.y)else q.lineTo(z.x,z.y)}
            c.drawPath(q,p)
        }

        if(buoy!=null&&committee!=null){
            val b=merc(buoy!!,ctr);val co=merc(committee!!,ctr)
            p.pathEffect=null;p.color=Color.BLACK;p.strokeWidth=9f;c.drawLine(b.x,b.y,co.x,co.y,p)

            val w=windProvider()
            drawRay(c,buoy!!,w+135,Color.RED,ctr)
            drawRay(c,buoy!!,w-135,Color.RED,ctr)
            drawRay(c,committee!!,w+135,Color.rgb(46,125,50),ctr)
            drawRay(c,committee!!,w-135,Color.rgb(46,125,50),ctr)
        }

        buoy?.let{point(c,merc(it,ctr),Color.rgb(21,101,192),"BOUÉE")}
        committee?.let{point(c,merc(it,ctr),Color.rgb(198,40,40),"COMITÉ")}

        // Large wind arrow, compass-referenced: 0=N, 90=E.
        drawArrow(c,PointF(width*0.78f,height*0.50f),windProvider(),90f,Color.rgb(30,100,210),7f)

        boat?.let{
            val bp=merc(it,ctr);drawBoat(c,bp,heading)
            val dtl=dtlAlongHeading(it)
            val t=if(dtl>=0&&speed>0.1)dtl/(speed*0.514444) else Double.POSITIVE_INFINITY
            val rem=timerSecondsProvider().toDouble()
            val color=when{
                dtl<0->Color.DKGRAY
                t<rem->Color.RED
                t<=rem+2.0->Color.rgb(210,150,0)
                else->Color.rgb(46,125,50)
            }
            onMetrics(dtl,speed,heading,color,t)
        } ?: onMetrics(-1.0,speed,heading,Color.DKGRAY,Double.POSITIVE_INFINITY)
    }

    private fun drawRay(c:Canvas,s:Geo,b:Double,col:Int,ctr:Geo){
        p.style=Paint.Style.STROKE;p.color=col;p.strokeWidth=4f
        p.pathEffect=DashPathEffect(floatArrayOf(15f,12f),0f)
        c.drawPath(rayPath(s,b,3000.0,ctr),p);p.pathEffect=null
    }
    private fun point(c:Canvas,z:PointF,col:Int,label:String){
        p.style=Paint.Style.FILL;p.color=col;c.drawCircle(z.x,z.y,14f,p)
        p.color=Color.DKGRAY;p.textSize=17f;c.drawText(label,z.x+20,z.y+6,p)
    }
    private fun drawArrow(c:Canvas,o:PointF,b:Double,len:Float,col:Int,w:Float){
        val a=Math.toRadians(b);val e=PointF(o.x+sin(a).toFloat()*len,o.y-cos(a).toFloat()*len)
        p.style=Paint.Style.STROKE;p.color=col;p.strokeWidth=w;c.drawLine(o.x,o.y,e.x,e.y,p)
        for(d in listOf(b+150,b-150)){val q=Math.toRadians(d);c.drawLine(e.x,e.y,e.x+sin(q).toFloat()*25,e.y-cos(q).toFloat()*25,p)}
        p.style=Paint.Style.FILL;c.drawCircle(o.x,o.y,7f,p)
    }
    private fun drawBoat(c:Canvas,o:PointF,b:Double){
        val a=Math.toRadians(b)
        fun r(x:Float,y:Float)=PointF(o.x+x*cos(a).toFloat()+y*sin(a).toFloat(),o.y-x*sin(a).toFloat()+y*cos(a).toFloat())
        val t=r(35f,0f);val l=r(-27f,-13f);val rr=r(-27f,13f)
        val q=Path().apply{moveTo(t.x,t.y);lineTo(l.x,l.y);lineTo(rr.x,rr.y);close()}
        p.style=Paint.Style.FILL;p.color=Color.BLACK;c.drawPath(q,p)
    }

    // Distance from boat to the race line measured along the current heading,
    // only if the forward heading ray intersects the finite Bouée-Comité segment.
    private fun dtlAlongHeading(pos:Geo):Double{
        val a=buoy?:return -1.0;val b=committee?:return -1.0
        val lat0=Math.toRadians((a.lat+b.lat+pos.lat)/3)
        fun xy(g:Geo):DoubleArray=doubleArrayOf(
            Math.toRadians(g.lon-a.lon)*6371000*cos(lat0),
            Math.toRadians(g.lat-a.lat)*6371000
        )
        val P=xy(pos);val A=xy(a);val B=xy(b)
        val sx=B[0]-A[0];val sy=B[1]-A[1]
        val h=Math.toRadians(((heading%360)+360)%360)
        val hx=sin(h);val hy=cos(h)
        val den=hx*sy-hy*sx
        if(abs(den)<1e-9)return -1.0
        val ax=A[0]-P[0];val ay=A[1]-P[1]
        val u=(ax*sy-ay*sx)/den // distance along heading
        val v=(ax*hy-ay*hx)/den // position along line parameter
        return if(u>=0 && v in 0.0..1.0)u else -1.0
    }
}
