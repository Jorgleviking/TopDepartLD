# TopDepartLDtestv4

Version de test basée sur TopDepartLDtestv2.

- Vue 2D conservée visuellement, avec correction du déplacement tactile après zoom/pincement.
- Le zoom par pincement reste centré sur le point entre les doigts.
- Vue 3D/drone séparée par bouton.
- Vue 3D sur fond noir, sans décor photographique.
- Bateau 3D : coque sportive sans voile, avec vrai volume visible (flancs, tableau arrière, pont, cockpit et détails).
- En v4, les boutons **2D** et **☰** qui étaient en haut à droite sont déplacés dans la barre inférieure, juste à côté de **LIGNE** ; **H** est regroupé au même endroit pour le réglage de hauteur 3D.
- Nouveau bouton **H** pour régler la hauteur de point de vue 3D : basse, moyenne ou haute.
- Les réglages de hauteur modifient la perspective de la vue 3D sans modifier la vue 2D.
