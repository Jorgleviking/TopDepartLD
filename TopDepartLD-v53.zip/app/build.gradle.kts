plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "fr.nauticalstart.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "fr.nauticalstart.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 52
        versionName = "52"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
