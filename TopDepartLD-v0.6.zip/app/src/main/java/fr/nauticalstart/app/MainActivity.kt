package fr.nauticalstart.app

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import java.util.Locale
import kotlin.math.*

data class Geo(val lat: Double, val lon: Double)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var board: NavView
    private lateinit var fused: FusedLocationProviderClient
    private var tts: TextToSpeech? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            fitsSystemWindows = true
        }

        // --- Top information row ---
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
        }

        fun infoBox(title: String, initial: String, weight: Float): Pair<LinearLayout, TextView> {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(2), dp(4), dp(2))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE)
                    setStroke(dp(1), Color.rgb(225,225,225))
                    cornerRadius = dp(5).toFloat()
                }
            }
            val titleView = TextView(this).apply {
                text = title
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(Color.DKGRAY)
                typeface = Typeface.DEFAULT_BOLD
            }
            val valueView = TextView(this).apply {
                text = initial
                textSize = 17f
                gravity = Gravity.CENTER
                setTextColor(Color.BLACK)
            }
            box.addView(titleView, LinearLayout.LayoutParams(-1, dp(22)))
            box.addView(valueView, LinearLayout.LayoutParams(-1, dp(30)))
            top.addView(box, LinearLayout.LayoutParams(0, dp(58), weight).apply {
                leftMargin = dp(2); rightMargin = dp(2)
            })
            return Pair(box, valueView)
        }

        val (_, lineValue) = infoBox("LONGUEUR DE LIGNE", "— m", 1f)

        val windBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(2), dp(4), dp(2))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                setStroke(dp(1), Color.rgb(225,225,225))
                cornerRadius = dp(5).toFloat()
            }
        }
        windBox.addView(TextView(this).apply {
            text = "DIRECTION DU VENT"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(-1, dp(22)))
        val windInput = EditText(this).apply {
            hint = "000°"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine()
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 0)
        }
        windBox.addView(windInput, LinearLayout.LayoutParams(-1, dp(30)))
        top.addView(windBox, LinearLayout.LayoutParams(0, dp(58), 1f).apply {
            leftMargin = dp(2); rightMargin = dp(2)
        })

        val dtlValue = infoBox("DTL", "— m  /  — L", 1f).second
        dtlValue.setTextColor(Color.DKGRAY)
        root.addView(top)

        // --- Canvas ---
        board = NavView(this) {
            lineValue.text = if (it >= 0) "%.0f m".format(it) else "— m"
        }
        board.windProvider = {
            windInput.text.toString().toDoubleOrNull()?.mod(360.0) ?: 0.0
        }
        board.statusProvider = { d, _, col ->
            dtlValue.text = if (d >= 0) "%.1f m  /  %.1f L".format(d, d / 11.0) else "— m  /  — L"
            dtlValue.setTextColor(col)
        }
        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))

        // --- Bottom controls ---
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(6), dp(6), dp(6), dp(8))
            gravity = Gravity.CENTER
        }

        fun action(text: String, fill: Int, onClick: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                textSize = 12f
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(fill)
                    cornerRadius = dp(5).toFloat()
                }
                setPadding(dp(2), 0, dp(2), 0)
                setOnClickListener { onClick() }
            }

        val weights = 1f
        bottom.addView(action("BOUÉE", Color.rgb(21,101,192)) { board.saveBuoy() },
            LinearLayout.LayoutParams(0, dp(52), weights).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("COMITÉ", Color.rgb(198,40,40)) { board.saveCommittee() },
            LinearLayout.LayoutParams(0, dp(52), weights).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("EFFACER", Color.rgb(70,70,70)) { board.clearMarks() },
            LinearLayout.LayoutParams(0, dp(52), weights).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("CENTRER", Color.rgb(46,125,50)) { board.centerOnBoat() },
            LinearLayout.LayoutParams(0, dp(52), weights).apply { leftMargin = dp(2); rightMargin = dp(2) })
        root.addView(bottom)

        setContentView(root)
        requestLocation()
    }

    private fun requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 42
            )
            return
        }
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000)
            .setMinUpdateIntervalMillis(500)
            .setMaxUpdateDelayMillis(1500)
            .build()
        fused = LocationServices.getFusedLocationProviderClient(this)
        fused.requestLocationUpdates(request, object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc ->
                    board.updateLocation(
                        Geo(loc.latitude, loc.longitude),
                        if (loc.hasBearing()) loc.bearing.toDouble() else board.lastHeading,
                        if (loc.hasSpeed()) loc.speed * 1.94384449 else board.lastSpeed
                    )
                }
            }
        }, Looper.getMainLooper())
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        if (r == 42) requestLocation()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.FRENCH
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

class NavView(
    context: android.content.Context,
    private val onLineLength: (Double) -> Unit
) : View(context) {

    var windProvider: () -> Double = { 0.0 }
    var statusProvider: (Double, Double, Int) -> Unit = { _, _, _ -> }

    var lastHeading = 0.0
    var lastSpeed = 0.0
    private var boat: Geo? = null
    private val trail = mutableListOf<Geo>()
    private var buoy: Geo? = null
    private var committee: Geo? = null
    private var center: Geo? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private var scale = 0.7

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isFocusable = true
    }

    fun updateLocation(g: Geo, heading: Double, speed: Double) {
        boat = g
        lastHeading = heading
        lastSpeed = speed
        if (trail.isEmpty() || haversine(trail.last(), g) > 1.5) trail.add(g)
        if (center == null) center = g
        invalidate()
    }

    fun saveBuoy() { boat?.let { buoy = it; if (center == null) center = it; invalidate(); reportLine() } }
    fun saveCommittee() { boat?.let { committee = it; if (center == null) center = it; invalidate(); reportLine() } }
    fun clearMarks() { buoy = null; committee = null; invalidate(); reportLine() }
    fun centerOnBoat() { center = boat; invalidate() }

    private fun reportLine() {
        val d = if (buoy != null && committee != null) haversine(buoy!!, committee!!) else -1.0
        onLineLength(d)
    }

    private fun haversine(a: Geo, b: Geo): Double {
        val R = 6371000.0
        val p1 = Math.toRadians(a.lat)
        val p2 = Math.toRadians(b.lat)
        val dp = Math.toRadians(b.lat - a.lat)
        val dl = Math.toRadians(b.lon - a.lon)
        val x = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * R * atan2(sqrt(x), sqrt(1 - x))
    }

    private fun project(g: Geo, c: Geo): PointF {
        val R = 6378137.0
        val x = R * Math.toRadians(g.lon)
        val y = R * ln(tan(Math.PI / 4 + Math.toRadians(g.lat) / 2))
        val cx = R * Math.toRadians(c.lon)
        val cy = R * ln(tan(Math.PI / 4 + Math.toRadians(c.lat) / 2))
        val metersPerPixel = 1.0 / max(scale, 0.000001)
        return PointF(
            (width / 2f + ((x - cx) / metersPerPixel)).toFloat(),
            (height / 2f - ((y - cy) / metersPerPixel)).toFloat()
        )
    }

    private fun bearingPoint(g: Geo, bearingDeg: Double, distanceM: Double): Geo {
        val R = 6371000.0
        val br = Math.toRadians((bearingDeg % 360 + 360) % 360)
        val lat1 = Math.toRadians(g.lat)
        val lon1 = Math.toRadians(g.lon)
        val d = distanceM / R
        val lat2 = asin(sin(lat1) * cos(d) + cos(lat1) * sin(d) * cos(br))
        val lon2 = lon1 + atan2(sin(br) * sin(d) * cos(lat1), cos(d) - sin(lat1) * sin(lat2))
        return Geo(Math.toDegrees(lat2), Math.toDegrees(lon2))
    }

    private fun destinationLine(start: Geo, bearing: Double, length: Double, c: Geo): Path {
        val end = bearingPoint(start, bearing, length)
        val p1 = project(start, c)
        val p2 = project(end, c)
        return Path().apply { moveTo(p1.x, p1.y); lineTo(p2.x, p2.y) }
    }

    private fun pointLineDistanceAndAlong(boat: Geo, a: Geo, b: Geo, heading: Double): Double {
        val lat0 = Math.toRadians((a.lat + b.lat + boat.lat) / 3.0)
        fun xy(g: Geo): DoubleArray {
            val east = Math.toRadians(g.lon - a.lon) * 6371000.0 * cos(lat0)
            val north = Math.toRadians(g.lat - a.lat) * 6371000.0
            return doubleArrayOf(east, north)
        }
        val p = xy(boat)
        val q = xy(a)
        val r = xy(b)
        val dx = r[0] - q[0]
        val dy = r[1] - q[1]
        val denom = dx * dx + dy * dy
        if (denom < 1e-6) return -1.0
        val t = ((p[0] - q[0]) * dx + (p[1] - q[1]) * dy) / denom
        if (t !in 0.0..1.0) return -1.0
        val projx = q[0] + t * dx
        val projy = q[1] + t * dy
        val h = Math.toRadians((heading % 360 + 360) % 360)
        val vx = sin(h)
        val vy = cos(h)
        val ex = projx - p[0]
        val ey = projy - p[1]
        return ex * vx + ey * vy
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.WHITE)
        val c = center ?: boat ?: Geo(0.0, 0.0)

        // Grid
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = 0x16000000
        val grid = 72f
        var x = width / 2f % grid
        while (x < width) { canvas.drawLine(x, 0f, x, height.toFloat(), paint); x += grid }
        var y = height / 2f % grid
        while (y < height) { canvas.drawLine(0f, y, width.toFloat(), y, paint); y += grid }

        // Trail
        if (trail.size > 1) {
            paint.color = 0x40555555
            paint.strokeWidth = 5f
            val path = Path()
            trail.forEachIndexed { i, g ->
                val p = project(g, c)
                if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
            }
            canvas.drawPath(path, paint)
        }

        // Race line and laylines
        if (buoy != null && committee != null) {
            val b = project(buoy!!, c)
            val co = project(committee!!, c)
            paint.color = Color.BLACK
            paint.strokeWidth = 8f
            paint.pathEffect = null
            canvas.drawLine(b.x, b.y, co.x, co.y, paint)

            val wind = windProvider().mod(360.0)
            drawRay(canvas, buoy!!, wind + 135, Color.RED, c)
            drawRay(canvas, buoy!!, wind - 135, Color.RED, c)
            drawRay(canvas, committee!!, wind + 135, Color.rgb(46, 125, 50), c)
            drawRay(canvas, committee!!, wind - 135, Color.rgb(46, 125, 50), c)
        }

        buoy?.let { drawPoint(canvas, project(it, c), Color.rgb(21, 101, 192), "BOUÉE") }
        committee?.let { drawPoint(canvas, project(it, c), Color.rgb(198, 40, 40), "COMITÉ") }

        // Wind arrow
        val wind = windProvider().mod(360.0)
        drawArrow(canvas, PointF(width * 0.78f, height * 0.20f), wind, 65f, Color.rgb(30, 100, 210), 6f)

        // Boat
        boat?.let {
            val p = project(it, c)
            drawBoat(canvas, p, lastHeading)
            val d = if (buoy != null && committee != null)
                pointLineDistanceAndAlong(it, buoy!!, committee!!, lastHeading) else -1.0
            statusProvider(d, if (d >= 0) d / 11.0 else -1.0,
                if (d >= 0) Color.rgb(46, 125, 50) else Color.DKGRAY)
        }

        paint.style = Paint.Style.FILL
        paint.color = Color.DKGRAY
        paint.textSize = 14f
        canvas.drawText("Vent %.0f°".format(wind), 14f, 24f, paint)
        canvas.drawText("100 m", width - 60f, height - 14f, paint)
    }

    private fun drawRay(canvas: Canvas, start: Geo, bearing: Double, color: Int, c: Geo) {
        paint.color = color
        paint.strokeWidth = 3f
        paint.style = Paint.Style.STROKE
        paint.pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
        canvas.drawPath(destinationLine(start, bearing, 3000.0, c), paint)
        paint.pathEffect = null
    }

    private fun drawPoint(canvas: Canvas, p: PointF, color: Int, text: String) {
        paint.style = Paint.Style.FILL
        paint.color = color
        canvas.drawCircle(p.x, p.y, 12f, paint)
        paint.color = Color.DKGRAY
        paint.textSize = 15f
        canvas.drawText(text, p.x + 17f, p.y + 5f, paint)
    }

    private fun drawArrow(canvas: Canvas, center: PointF, bearing: Double, len: Float, color: Int, width: Float) {
        val a = Math.toRadians(bearing)
        val ex = center.x + sin(a).toFloat() * len
        val ey = center.y - cos(a).toFloat() * len
        paint.color = color
        paint.strokeWidth = width
        paint.style = Paint.Style.STROKE
        canvas.drawLine(center.x, center.y, ex, ey, paint)
        val left = Math.toRadians(bearing + 150)
        val right = Math.toRadians(bearing - 150)
        canvas.drawLine(ex, ey, ex + sin(left).toFloat() * 18f, ey - cos(left).toFloat() * 18f, paint)
        canvas.drawLine(ex, ey, ex + sin(right).toFloat() * 18f, ey - cos(right).toFloat() * 18f, paint)
        paint.style = Paint.Style.FILL
        canvas.drawCircle(center.x, center.y, 6f, paint)
    }

    private fun drawBoat(canvas: Canvas, p: PointF, bearing: Double) {
        val a = Math.toRadians(bearing)
        fun rot(x: Float, y: Float): PointF =
            PointF(
                p.x + x * cos(a).toFloat() + y * sin(a).toFloat(),
                p.y - x * sin(a).toFloat() + y * cos(a).toFloat()
            )
        val tip = rot(30f, 0f)
        val l = rot(-23f, -11f)
        val r = rot(-23f, 11f)
        val path = Path().apply {
            moveTo(tip.x, tip.y); lineTo(l.x, l.y); lineTo(r.x, r.y); close()
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.BLACK
        canvas.drawPath(path, paint)
    }
}
