# TopDepartLD v0.6

Version 0.6 de l'application de navigation/tactique de régate.

Principales modifications :
- nom de l'application : TopDepartLD v0.6 ;
- version Android : 0.6.0 / versionCode 6 ;
- mode portrait ;
- nouvelle barre supérieure avec LONGUEUR DE LIGNE, DIRECTION DU VENT et DTL ;
- canevas blanc quadrillé sans fond de carte ;
- boutons BOUÉE, COMITÉ, EFFACER et CENTRER en bas ;
- GPS haute précision, trace, ligne Bouée-Comité, flèche de vent et DTL conservés ;
- chaque nouvelle version devra incrémenter le numéro affiché et les métadonnées Android.
