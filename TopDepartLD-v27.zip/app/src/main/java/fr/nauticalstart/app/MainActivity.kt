package fr.nauticalstart.app

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.content.pm.PackageManager
import android.graphics.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.*
import java.util.Locale
import kotlin.math.*

data class Geo(val lat: Double, val lon: Double)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var board: NavView
    private lateinit var fused: FusedLocationProviderClient
    private var tts: TextToSpeech? = null
    private var ocsAlarmActive = false
    private var toneGenerator: ToneGenerator? = null
    private var raceActive = false
    private var raceFinished = false
    private var raceStartElapsed = 0L
    private var raceTicker: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(7, 20, 29))
        }

        // Android 15/targetSdk 35 can draw behind system bars. Keep the UI
        // inside the usable area so the right-side navigation bar never
        // covers controls on landscape phones.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

        fun label(text: String, size: Float = 15f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(Color.DKGRAY)
                gravity = Gravity.CENTER
                maxLines = 2
                includeFontPadding = true
            }

        // v0.8 — barre supérieure dessinée comme une vraie rangée de cases.
        // Chaque case prend une largeur proportionnelle : aucun texte ne peut
        // déborder ou se superposer, même sur un téléphone différent.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            setPadding(dp(4), 0, dp(4), 0)
        }

        fun boxBackground(): android.graphics.drawable.GradientDrawable =
            android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(10, 25, 35))
                setStroke(dp(1), Color.rgb(55, 70, 78))
                cornerRadius = dp(5).toFloat()
            }

        fun valueLabel(text: String, size: Float = 17f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(Color.rgb(235, 240, 243))
                gravity = Gravity.CENTER
                maxLines = 1
                includeFontPadding = false
                typeface = Typeface.DEFAULT_BOLD
                ellipsize = android.text.TextUtils.TruncateAt.END
            }

        fun titleLabel(text: String): TextView =
            TextView(this).apply {
                this.text = text
                textSize = 12f
                setTextColor(Color.rgb(190, 202, 208))
                gravity = Gravity.CENTER
                maxLines = 1
                includeFontPadding = false
                typeface = Typeface.DEFAULT
            }

        fun makeCell(weight: Float, content: View): View {
            val frame = FrameLayout(this).apply {
                background = boxBackground()
                addView(content, FrameLayout.LayoutParams(-1, -1))
            }
            top.addView(frame, LinearLayout.LayoutParams(0, dp(60), weight).apply {
                leftMargin = dp(2)
                rightMargin = dp(2)
            })
            return frame
        }

        fun makeStack(title: String, value: String): LinearLayout =
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(2), dp(3), dp(2))
                addView(titleLabel(title), LinearLayout.LayoutParams(-1, 0, 0.8f))
                addView(valueLabel(value), LinearLayout.LayoutParams(-1, 0, 1.2f))
            }

        val windInput = EditText(this).apply {
            hint = "000"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            textSize = 18f
            gravity = Gravity.CENTER
            setOnFocusChangeListener { v, hasFocus -> if (hasFocus) (v as EditText).selectAll() }
            setTextColor(Color.rgb(240, 245, 247))
            setHintTextColor(Color.rgb(110, 125, 132))
            setPadding(0, 0, 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
        }
        val windCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(2), dp(3), dp(2))
            addView(titleLabel("DIRECTION VENT"), LinearLayout.LayoutParams(-1, 0, 0.8f))
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.addView(windInput, LinearLayout.LayoutParams(dp(78), -1))
            row.addView(valueLabel("°", 18f), LinearLayout.LayoutParams(dp(22), -1))
            addView(row, LinearLayout.LayoutParams(-1, 0, 1.2f))
        }
        makeCell(1.00f, windCell)

        val speed = valueLabel("— kn", 16f)
        val heading = valueLabel("—°", 16f)
        val speedHeadingCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(2), dp(3), dp(2))
            addView(titleLabel("VITESSE / CAP"), LinearLayout.LayoutParams(-1, 0, 0.8f))
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                addView(speed, LinearLayout.LayoutParams(0, -1, 1f))
                addView(valueLabel("  |  ", 13f), LinearLayout.LayoutParams(dp(34), -1))
                addView(heading, LinearLayout.LayoutParams(0, -1, 1f))
            }
            addView(row, LinearLayout.LayoutParams(-1, 0, 1.2f))
        }
        makeCell(1.20f, speedHeadingCell)

        val dtl = valueLabel("— m  /  — L", 15f).apply {
            typeface = Typeface.DEFAULT_BOLD
        }
        val dtlCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(2), dp(3), dp(2))
            addView(titleLabel("LaL"), LinearLayout.LayoutParams(-1, 0, 0.8f))
            addView(dtl, LinearLayout.LayoutParams(-1, 0, 1.2f))
        }
        makeCell(0.90f, dtlCell)

        // Temps à la ligne + compte à rebours avec 3 commandes.
        val timeToLine = valueLabel("— s", 18f).apply {
            setTextColor(Color.rgb(235, 240, 243))
        }
        val timeCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(2), dp(3), dp(2))
            addView(titleLabel("TaL"), LinearLayout.LayoutParams(-1, 0, 0.8f))
            addView(timeToLine, LinearLayout.LayoutParams(-1, 0, 1.2f))
        }
        makeCell(0.85f, timeCell)

        // Colonne compte à rebours à droite de tout l'écran. Le compte à rebours
        // reste large et lisible, tandis que les commandes sont empilées dessous.
        val timer = valueLabel("05:00", 34f).apply {
            setTextColor(Color.RED)
            gravity = Gravity.CENTER
            ellipsize = null
        }
        val raceTime = valueLabel("—", 22f).apply {
            setTextColor(Color.rgb(57, 255, 20))
        }
        val raceTimeCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = boxBackground()
            addView(titleLabel("TEMPS APRÈS DÉPART"), LinearLayout.LayoutParams(-1, 0, 0.75f))
            addView(raceTime, LinearLayout.LayoutParams(-1, 0, 1.25f))
            visibility = View.GONE
        }

        fun timerButton(textValue: String, bg: Int, size: Float, description: String): Button = Button(this).apply {
            text = textValue
            textSize = size
            setTextColor(Color.WHITE)
            background = ColorDrawable(bg)
            contentDescription = description
            minWidth = 0; minimumWidth = 0
            setPadding(0, 0, 0, 0)
            includeFontPadding = false
            isAllCaps = false
        }
        val start = timerButton("START", Color.rgb(20, 115, 30), 13f, "Démarrer le compte à rebours")
        val stop = timerButton("STOP", Color.rgb(190, 35, 35), 13f, "Arrêter le compte à rebours")
        val reset = timerButton("RESET", Color.rgb(45, 55, 62), 12f, "Réinitialiser le compte à rebours à 05:00")
        val sync = timerButton("SYNC", Color.rgb(28, 45, 55), 13f, "Synchroniser le compte à rebours à la minute entière la plus proche")

        val timerPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(3), 0, dp(3), dp(3))
            background = boxBackground()
        }
        timerPanel.addView(timer, LinearLayout.LayoutParams(-1, dp(78)))
        timerPanel.addView(raceTimeCell, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(2) })
        fun compactTimerButton(button: Button): LinearLayout.LayoutParams =
            LinearLayout.LayoutParams(dp(112), dp(44)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(4)
            }
        timerPanel.addView(start, compactTimerButton(start))
        timerPanel.addView(stop, compactTimerButton(stop))
        timerPanel.addView(reset, compactTimerButton(reset))
        timerPanel.addView(sync, compactTimerButton(sync))

        // Zone principale à gauche : ligne supérieure, canevas puis boutons bas.
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
        }
        main.addView(top, LinearLayout.LayoutParams(-1, dp(72)))

        var lineCapText: TextView? = null
        var lineLengthText: TextView? = null
        board = NavView(this) { cap, length ->
            lineCapText?.text = if (cap >= 0) "%03d°".format(cap.roundToInt()) else "—°"
            lineLengthText?.text = if (length >= 0) "%.0f m".format(length) else "— m"
        }
        board.raceActiveProvider = { raceActive }
        board.raceStartElapsedProvider = { raceStartElapsed }
        board.onRaceFinished = { elapsedMs ->
            if (!raceFinished) {
                raceFinished = true
                raceActive = false
                raceTime.text = formatRaceTime(elapsedMs)
                raceTimeCell.visibility = View.VISIBLE
            }
        }
        board.windProvider = { windInput.text.toString().toDoubleOrNull()?.mod(360.0) ?: 0.0 }
        board.statusProvider = { d, n, col ->
            dtl.text = if (d >= 0) "%.1f m / %.1f L".format(d, d / 11.0) else "— m / — L"
            dtl.setTextColor(Color.rgb(235, 240, 243))
            val seconds = if (d >= 0 && board.lastSpeed > 0.3) (d / (board.lastSpeed * 0.514444)).roundToInt() else -1
            timeToLine.text = if (seconds >= 0) "${seconds} s" else "— s"
            val delta = if (seconds >= 0) seconds - board.countdownSeconds else Int.MIN_VALUE
            timeToLine.setTextColor(when {
                seconds < 0 -> Color.rgb(235, 240, 243)
                seconds < board.countdownSeconds -> Color.RED
                delta < 2 -> Color.rgb(255, 165, 0)
                else -> Color.rgb(70, 210, 90)
            })
        }
        board.speedProvider = { s -> speed.text = "%.1f kn".format(s) }
        board.headingProvider = { h -> heading.text = "%03d°".format(((h % 360 + 360) % 360).roundToInt()) }
        board.ocsProvider = { active ->
            if (active && !ocsAlarmActive) {
                ocsAlarmActive = true
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 700)
                speak("OCS")
            } else if (!active) {
                ocsAlarmActive = false
            }
        }

        main.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        fun action(text: String, color: Int, textSizeSp: Float, onClick: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                setTextColor(Color.WHITE)
                background = ColorDrawable(color)
                setOnClickListener { onClick() }
                textSize = textSizeSp
                minWidth = 0; minimumWidth = 0
                maxLines = 1
                isAllCaps = false
                setPadding(dp(1), 0, dp(1), 0)
                includeFontPadding = false
            }
        bottom.addView(action("BOUÉE", Color.rgb(21,101,192), 13f) { board.saveBuoy() },
            LinearLayout.LayoutParams(0, dp(35), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("COMITÉ", Color.rgb(198,40,40), 13f) { board.saveCommittee() },
            LinearLayout.LayoutParams(0, dp(35), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })

        val lineCell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(10, 25, 35))
                setStroke(dp(1), Color.rgb(57, 255, 20))
                cornerRadius = dp(5).toFloat()
            }
            setPadding(dp(5), 0, dp(5), 0)
        }
        val lineTitle = titleLabel("LIGNE").apply {
            setTextColor(Color.rgb(57,255,20))
            typeface = Typeface.DEFAULT_BOLD
        }
        lineCapText = valueLabel("—°", 16f)
        lineLengthText = valueLabel("— m", 16f)
        val capBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(lineCapText, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(titleLabel("Cap Comité → Bouée"), LinearLayout.LayoutParams(-1, 0, 0.75f))
        }
        val lengthBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(lineLengthText, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(titleLabel("Longueur"), LinearLayout.LayoutParams(-1, 0, 0.75f))
        }
        lineCell.addView(capBlock, LinearLayout.LayoutParams(0, -1, 1f))
        lineCell.addView(valueLabel("|", 13f), LinearLayout.LayoutParams(dp(18), -1))
        lineCell.addView(lengthBlock, LinearLayout.LayoutParams(0, -1, 1f))
        val lineFrame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(lineTitle, LinearLayout.LayoutParams(-1, 0, 0.7f))
            addView(lineCell, LinearLayout.LayoutParams(-1, 0, 1.65f))
        }
        bottom.addView(lineFrame, LinearLayout.LayoutParams(0, dp(43), 1.45f).apply {
            leftMargin = dp(2); rightMargin = dp(2)
        })
        main.addView(bottom, LinearLayout.LayoutParams(-1, dp(49)))
        root.addView(main, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(timerPanel, LinearLayout.LayoutParams(dp(190), -1))

        setContentView(root)

        var remaining = 300
        var running = false
        val handler = android.os.Handler(Looper.getMainLooper())
        fun beginRace() {
            if (raceActive) return
            raceActive = true
            raceFinished = false
            raceStartElapsed = SystemClock.elapsedRealtime()
            raceTimeCell.visibility = View.VISIBLE
            raceTime.text = "00:00.0"
            raceTicker?.let { handler.removeCallbacks(it) }
            val ticker = object : Runnable {
                override fun run() {
                    if (raceActive) {
                        raceTime.text = formatRaceTime(SystemClock.elapsedRealtime() - raceStartElapsed)
                        handler.postDelayed(this, 100)
                    }
                }
            }
            raceTicker = ticker
            handler.post(ticker)
        }
        start.setOnClickListener { running = true }
        stop.setOnClickListener { running = false }
        reset.setOnClickListener {
            remaining = 300
            board.countdownSeconds = 300
            running = false
            raceActive = false
            raceFinished = false
            raceStartElapsed = 0L
            raceTicker?.let { handler.removeCallbacks(it) }
            raceTime.text = "—"
            raceTimeCell.visibility = View.GONE
            timer.text = "05:00"
            board.updateOcsState()
            board.invalidate()
        }
        sync.setOnClickListener {
            // Arrondi à la minute entière la plus proche (ex. 04:37 -> 05:00,
            // 04:23 -> 04:00). Le chronomètre reste dans son état marche/arrêt.
            remaining = ((remaining + 30) / 60) * 60
            board.countdownSeconds = remaining
            timer.text = "%02d:%02d".format(remaining / 60, remaining % 60)
            board.updateOcsState()
            board.invalidate()
        }

        val tick = object : Runnable {
            override fun run() {
                if (running && remaining > 0) {
                    remaining--
                    board.countdownSeconds = remaining
                    val mm = remaining / 60
                    val ss = remaining % 60
                    timer.text = "%02d:%02d".format(mm, ss)
                    board.updateOcsState()
                    when {
                        remaining > 60 && ss == 0 -> speak("$mm minutes")
                        remaining in 10..60 && remaining % 10 == 0 -> speak(
                            if (remaining == 60) "1 minute" else "$remaining secondes"
                        )
                        remaining in 1..9 -> speak("$remaining")
                        remaining == 0 -> {
                            speak("Départ")
                            beginRace()
                        }
                    }
                }
                handler.postDelayed(this, 1000)
            }
        }
        handler.postDelayed(tick, 1000)
        toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)

        fused = LocationServices.getFusedLocationProviderClient(this)
        requestLocation()
    }

    private fun formatRaceTime(elapsedMs: Long): String {
        val tenths = (elapsedMs / 100L) % 10L
        val totalSeconds = elapsedMs / 1000L
        val mm = totalSeconds / 60L
        val ss = totalSeconds % 60L
        return "%02d:%02d.%d".format(mm, ss, tenths)
    }

    private fun requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 42
            )
            return
        }
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000)
            .setMinUpdateIntervalMillis(500)
            .setMaxUpdateDelayMillis(1500)
            .build()
        fused.requestLocationUpdates(request, object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc ->
                    board.updateLocation(
                        Geo(loc.latitude, loc.longitude),
                        if (loc.hasBearing()) loc.bearing.toDouble() else board.lastHeading,
                        if (loc.hasSpeed()) loc.speed * 1.94384449 else board.lastSpeed
                    )
                }
            }
        }, Looper.getMainLooper())
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        if (r == 42) requestLocation()
    }

    private fun speak(s: String) {
        tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "countdown")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.FRENCH
        }
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        toneGenerator?.release(); toneGenerator = null
        super.onDestroy()
    }
}

class NavView(
    context: android.content.Context,
    private val onLineInfo: (Double, Double) -> Unit
) : View(context) {

    var windProvider: () -> Double = { 0.0 }
    var statusProvider: (Double, Double, Int) -> Unit = { _,_,_ -> }
    var speedProvider: (Double) -> Unit = {}
    var headingProvider: (Double) -> Unit = {}
    var ocsProvider: (Boolean) -> Unit = {}
    var raceActiveProvider: () -> Boolean = { false }
    var raceStartElapsedProvider: () -> Long = { 0L }
    var onRaceFinished: (Long) -> Unit = {}

    var lastHeading = 0.0
    var lastSpeed = 0.0
    private var boat: Geo? = null
    private var previousBoat: Geo? = null
    private val trail = mutableListOf<Geo>()
    private var buoy: Geo? = null
    private var committee: Geo? = null
    private var center: Geo? = null
    private var lineLengthMeters: Double = -1.0
    // Current race countdown, in seconds, shared with the TaL color logic.
    var countdownSeconds: Int = 300

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private var scale = 1.8f // pixels per metre at zoom 1.0

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isFocusable = true
    }

    fun updateLocation(g: Geo, heading: Double, speed: Double) {
        val oldBoat = boat
        if (raceActiveProvider() && oldBoat != null && buoy != null && committee != null && crossedStartLine(oldBoat, g)) {
            onRaceFinished(SystemClock.elapsedRealtime() - raceStartElapsedProvider())
        }
        previousBoat = oldBoat
        boat = g; lastHeading = heading; lastSpeed = speed
        if (trail.isEmpty() || haversine(trail.last(), g) > 1.5) trail.add(g)
        if (center == null) center = g
        speedProvider(speed); headingProvider(heading)
        updateOcsState()
        invalidate()
    }

    fun saveBuoy() { boat?.let { buoy = it; if (center == null) center = it; invalidate(); reportLine() } }
    fun saveCommittee() { boat?.let { committee = it; if (center == null) center = it; invalidate(); reportLine() } }
    fun centerOnBoat() { center = boat; invalidate() }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
                // The zoom buttons are handled on ACTION_UP; don't pan when
                // the gesture starts on one of them.
                panEnabled = !(event.x in 18f..100f && (event.y in 82f..142f || event.y in 147f..207f))
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                pinchStartDistance = distance(event)
                pinchStartScale = scale
                panEnabled = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    val d = distance(event)
                    if (pinchStartDistance > 0f) {
                        scale = (pinchStartScale * (d / pinchStartDistance)).coerceIn(0.45f, 12f)
                        invalidate()
                    }
                } else if (event.pointerCount == 1 && panEnabled) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    panX += dx
                    panY += dy
                    lastTouchX = event.x
                    lastTouchY = event.y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val x = event.x; val y = event.y
                if (x in 18f..100f && y in 82f..142f) {
                    scale = (scale * 1.35f).coerceAtMost(12f)
                    invalidate()
                    return true
                }
                if (x in 18f..100f && y in 147f..207f) {
                    scale = (scale / 1.35f).coerceAtLeast(0.45f)
                    invalidate()
                    return true
                }
                panEnabled = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                panEnabled = false
                return true
            }
        }
        return true
    }

    private var pinchStartDistance = 0f
    private var pinchStartScale = 1.8f
    private var panX = 0f
    private var panY = 0f
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var panEnabled = false

    private fun distance(e: MotionEvent): Float {
        if (e.pointerCount < 2) return 0f
        val dx = e.getX(0) - e.getX(1)
        val dy = e.getY(0) - e.getY(1)
        return hypot(dx, dy)
    }


    private fun crossedStartLine(from: Geo, to: Geo): Boolean {
        val a = committee ?: return false
        val b = buoy ?: return false
        val lat0 = Math.toRadians((a.lat + b.lat + from.lat + to.lat) / 4.0)
        fun xy(g: Geo): Pair<Double, Double> {
            val x = Math.toRadians(g.lon - a.lon) * 6371000.0 * cos(lat0)
            val y = Math.toRadians(g.lat - a.lat) * 6371000.0
            return x to y
        }
        val p = xy(from); val q = xy(to); val r = xy(a); val s = xy(b)
        fun cross(ax: Double, ay: Double, bx: Double, by: Double) = ax * by - ay * bx
        fun orient(p1: Pair<Double,Double>, p2: Pair<Double,Double>, p3: Pair<Double,Double>): Double =
            cross(p2.first-p1.first, p2.second-p1.second, p3.first-p1.first, p3.second-p1.second)
        val o1 = orient(p, q, r); val o2 = orient(p, q, s)
        val o3 = orient(r, s, p); val o4 = orient(r, s, q)
        val eps = 0.05
        return ((o1 > eps && o2 < -eps) || (o1 < -eps && o2 > eps)) &&
               ((o3 > eps && o4 < -eps) || (o3 < -eps && o4 > eps))
    }

    /**
     * OCS = bateau déjà du côté parcours de la ligne pendant la dernière
     * minute avant le départ. Le côté parcours est le côté vers lequel
     * souffle le vent (ventFrom + 180°).
     */
    fun updateOcsState() {
        val active = countdownSeconds in 1..60 && boat != null && buoy != null && committee != null && isOnCourseSide()
        ocsProvider(active)
    }

    private fun isOnCourseSide(): Boolean {
        val b = boat ?: return false
        val a = committee ?: return false
        val z = buoy ?: return false
        val lat0 = Math.toRadians((a.lat + z.lat + b.lat) / 3.0)
        fun xy(g: Geo): DoubleArray {
            val east = Math.toRadians(g.lon - a.lon) * 6371000.0 * cos(lat0)
            val north = Math.toRadians(g.lat - a.lat) * 6371000.0
            return doubleArrayOf(east, north)
        }
        val bp = xy(b)
        val zp = xy(z)
        val lx = zp[0]
        val ly = zp[1]
        val wx = sin(Math.toRadians((windProvider().mod(360.0) + 180.0).mod(360.0)))
        val wy = cos(Math.toRadians((windProvider().mod(360.0) + 180.0).mod(360.0)))
        // Dot product with the wind-flow vector: positive means the boat is
        // on the downwind/course side of the start line.
        val cross = lx * bp[1] - ly * bp[0]
        val lineNormalX = -ly
        val lineNormalY = lx
        val sign = lineNormalX * wx + lineNormalY * wy
        return cross * sign > 0.0
    }

    private fun reportLine() {
        val d = if (buoy != null && committee != null) haversine(buoy!!, committee!!) else -1.0
        lineLengthMeters = d
        val cap = if (buoy != null && committee != null) bearingBetween(committee!!, buoy!!) else -1.0
        onLineInfo(cap, d)
        invalidate()
    }

    private fun haversine(a: Geo, b: Geo): Double {
        val R = 6371000.0
        val p1 = Math.toRadians(a.lat); val p2 = Math.toRadians(b.lat)
        val dp = Math.toRadians(b.lat-a.lat); val dl = Math.toRadians(b.lon-a.lon)
        val x = sin(dp/2).pow(2) + cos(p1)*cos(p2)*sin(dl/2).pow(2)
        return 2*R*atan2(sqrt(x), sqrt(1-x))
    }

    // Cap géographique de la ligne comité -> bouée.
    // Sert uniquement à orienter l'affichage pour que la ligne de départ
    // soit horizontale dès que les deux marques sont enregistrées.
    private fun bearingBetween(a: Geo, b: Geo): Double {
        val lat1 = Math.toRadians(a.lat)
        val lat2 = Math.toRadians(b.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    // Web-Mercator screen coordinates around the chosen center.
    private fun project(g: Geo, c: Geo): PointF {
        val R = 6378137.0
        val x = R * Math.toRadians(g.lon)
        val y = R * ln(tan(Math.PI/4 + Math.toRadians(g.lat)/2))
        val cx = R * Math.toRadians(c.lon)
        val cy = R * ln(tan(Math.PI/4 + Math.toRadians(c.lat)/2))
        val pixelsPerMeter = max(scale, 0.000001f)
        return PointF(
            (width/2f + ((x-cx)*pixelsPerMeter)).toFloat(),
            (height/2f - ((y-cy)*pixelsPerMeter)).toFloat()
        )
    }

    private fun bearingPoint(g: Geo, bearingDeg: Double, distanceM: Double): Geo {
        val R = 6371000.0
        val br = Math.toRadians((bearingDeg % 360 + 360) % 360)
        val lat1 = Math.toRadians(g.lat)
        val lon1 = Math.toRadians(g.lon)
        val d = distanceM / R
        val lat2 = asin(sin(lat1)*cos(d) + cos(lat1)*sin(d)*cos(br))
        val lon2 = lon1 + atan2(sin(br)*sin(d)*cos(lat1), cos(d)-sin(lat1)*sin(lat2))
        return Geo(Math.toDegrees(lat2), Math.toDegrees(lon2))
    }

    private fun destinationLine(start: Geo, bearing: Double, length: Double, c: Geo): Path {
        val end = bearingPoint(start, bearing, length)
        val p1 = project(start, c); val p2 = project(end, c)
        return Path().apply { moveTo(p1.x,p1.y); lineTo(p2.x,p2.y) }
    }

    private fun forwardDistanceToLine(boat: Geo, a: Geo, b: Geo, heading: Double): Double {
        // Local tangent plane (east, north). We only report the distance
        // when the boat's heading ray intersects the race line segment A-B
        // somewhere IN FRONT of the boat. Otherwise no distance is shown.
        val lat0 = Math.toRadians((a.lat + b.lat + boat.lat) / 3.0)
        fun xy(g: Geo): DoubleArray {
            val east = Math.toRadians(g.lon - boat.lon) * 6371000.0 * cos(lat0)
            val north = Math.toRadians(g.lat - boat.lat) * 6371000.0
            return doubleArrayOf(east, north)
        }
        val p = doubleArrayOf(0.0, 0.0)
        val q = xy(a)
        val r = xy(b)
        val hx = sin(Math.toRadians(heading))
        val hy = cos(Math.toRadians(heading))
        val dx = r[0] - q[0]
        val dy = r[1] - q[1]
        val cross = hx * dy - hy * dx
        if (abs(cross) < 1e-9) return -1.0
        val qx = q[0]; val qy = q[1]
        val t = (qx * dy - qy * dx) / cross
        val u = (qx * hy - qy * hx) / cross
        return if (t >= 0.0 && u in 0.0..1.0) t else -1.0
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(7, 20, 29))
        val c = center ?: boat ?: Geo(0.0,0.0)
        val windFrom = windProvider().mod(360.0)
        // Avant le placement des deux marques, l'affichage reste référencé
        // par le vent. Dès que comité + bouée sont présents, la ligne de départ
        // devient la nouvelle référence visuelle et est automatiquement
        // horizontale à l'écran.
        //
        // En coordonnées écran (Est = +X, Nord = -Y), une rotation de
        // -90° - bearing rend la ligne horizontale avec le COMITÉ à droite
        // et la BOUÉE à gauche.
        val displayRotation = if (buoy != null && committee != null) {
            (-90.0 - bearingBetween(committee!!, buoy!!)).toFloat()
        } else {
            (-windFrom).toFloat()
        }

        canvas.save()
        canvas.rotate(displayRotation, width / 2f, height / 2f)
        canvas.translate(panX, panY)

        // Le quadrillage reste volontairement incliné de 45° par rapport
        // à la référence active de l'affichage, et remplit largement les
        // quatre coins afin qu'aucune zone vide n'apparaisse après rotation.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = Color.rgb(42, 62, 72)
        // One small grid square = representative boat length (10 m).
        val grid = 11f * scale
        val diagonal = hypot(width.toFloat(), height.toFloat()) + grid * 2f

        canvas.save()
        canvas.rotate(45f, width / 2f, height / 2f)
        var x = -diagonal
        while (x <= diagonal) {
            canvas.drawLine(x, -diagonal, x, diagonal, paint)
            x += grid
        }
        var y = -diagonal
        while (y <= diagonal) {
            canvas.drawLine(-diagonal, y, diagonal, y, paint)
            y += grid
        }
        canvas.restore()

        // Historical GPS trail, deliberately behind everything else.
        if(trail.size>1) {
            paint.color=0x40555555; paint.strokeWidth=5f; paint.style=Paint.Style.STROKE
            val path=Path()
            trail.forEachIndexed { i,g -> val p=project(g,c); if(i==0) path.moveTo(p.x,p.y) else path.lineTo(p.x,p.y) }
            canvas.drawPath(path,paint)
        }

        // La ligne comité-bouée est maintenant horizontale à l'écran dès que
        // les deux marques sont sélectionnées. Les laylines restent calculées
        // à partir de la direction du vent.
        if(buoy!=null && committee!=null) {
            val b=project(buoy!!,c); val co=project(committee!!,c)
            // High-visibility race start line: dark outline + fluorescent green core.
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 11f
            paint.color = Color.BLACK
            paint.pathEffect = null
            canvas.drawLine(b.x, b.y, co.x, co.y, paint)
            paint.strokeWidth = 7f
            paint.color = Color.rgb(57, 255, 20) // fluorescent green
            canvas.drawLine(b.x, b.y, co.x, co.y, paint)

            drawRay(canvas, buoy!!, windFrom+135, Color.RED, c)
            drawRay(canvas, buoy!!, windFrom-135, Color.RED, c)
            drawRay(canvas, committee!!, windFrom+135, Color.rgb(46,125,50), c)
            drawRay(canvas, committee!!, windFrom-135, Color.rgb(46,125,50), c)
        }

        // Points.
        buoy?.let { drawPoint(canvas, project(it,c), Color.rgb(21,101,192), "BOUÉE") }
        committee?.let { drawPoint(canvas, project(it,c), Color.rgb(198,40,40), "COMITÉ") }

        // Boat: elongated triangle, pointed along GPS heading.
        boat?.let {
            val p=project(it,c)
            drawBoat(canvas,p,lastHeading)
            val d=if(buoy!=null&&committee!=null) forwardDistanceToLine(it,buoy!!,committee!!,lastHeading) else -1.0
            val lengths=if(d>=0) d/11.0 else -1.0
            val timeToLine=if(d>=0 && lastSpeed>0.3) d/(lastSpeed*0.514444) else Double.POSITIVE_INFINITY
            val col=when {
                !timeToLine.isFinite() -> Color.DKGRAY
                timeToLine < countdownSeconds -> Color.RED
                timeToLine - countdownSeconds < 2.0 -> Color.rgb(255,165,0)
                else -> Color.rgb(46,125,50)
            }
            statusProvider(d,lengths,col)
        }

        canvas.restore()

        // Flèche du vent : la valeur saisie est la direction D'OÙ VIENT
        // le vent. La flèche indique donc OÙ IL SOUFFLE (+180°), en tenant
        // compte de la rotation actuelle de la carte.
        val windScreenBearing = windFrom + 180.0 + displayRotation
        val wc = PointF(width / 2f, 52f)
        drawArrow(canvas, wc, windScreenBearing, 52f, Color.WHITE, 5f)

        // Nord vrai : indépendant du vent et du cap du bateau. La flèche
        // suit l'orientation de la carte et indique toujours le nord
        // géographique à l'écran.
        paint.style=Paint.Style.FILL; paint.color=Color.rgb(235,240,243); paint.textSize=16f
        canvas.drawText("N", 47f, 24f, paint)
        drawArrow(canvas, PointF(52f, 52f), displayRotation.toDouble(), 30f, Color.WHITE, 3f)

        // Metric scale bar: always represents exactly 100 real metres.
        val barPx = (100f * scale).coerceIn(80f, width * 0.28f)
        paint.color=Color.rgb(230,235,238); paint.strokeWidth=2f; paint.style=Paint.Style.STROKE
        canvas.drawLine(width-barPx-28f, height-32f, width-28f, height-32f, paint)
        canvas.drawLine(width-barPx-28f, height-38f, width-barPx-28f, height-26f, paint)
        canvas.drawLine(width-28f, height-38f, width-28f, height-26f, paint)
        paint.style=Paint.Style.FILL; paint.textSize=14f
        canvas.drawText("100 m", width-barPx/2f-20f, height-44f, paint)

        // Boutons de zoom + / −
        paint.style = Paint.Style.FILL; paint.color = Color.rgb(12, 29, 39)
        canvas.drawRoundRect(18f, 82f, 100f, 142f, 12f, 12f, paint)
        canvas.drawRoundRect(18f, 147f, 100f, 207f, 12f, 12f, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = Color.rgb(70, 90, 100)
        canvas.drawRoundRect(18f, 82f, 100f, 142f, 12f, 12f, paint)
        canvas.drawRoundRect(18f, 147f, 100f, 207f, 12f, 12f, paint)
        paint.style = Paint.Style.FILL; paint.color = Color.WHITE; paint.textSize = 42f
        canvas.drawText("+", 42f, 126f, paint)
        canvas.drawText("−", 43f, 191f, paint)
    }

    private fun drawRay(canvas: Canvas, start: Geo, bearing: Double, color: Int, c: Geo) {
        paint.color=color; paint.strokeWidth=4f; paint.style=Paint.Style.STROKE
        paint.pathEffect=DashPathEffect(floatArrayOf(16f,12f),0f)
        canvas.drawPath(destinationLine(start,bearing,3000.0,c),paint)
        paint.pathEffect=null
    }

    private fun drawPoint(canvas: Canvas,p:PointF,color:Int,text:String){
        paint.style=Paint.Style.FILL; paint.color=color; canvas.drawCircle(p.x,p.y,14f,paint)
        paint.color=Color.DKGRAY; paint.textSize=18f; canvas.drawText(text,p.x+20,p.y+6,paint)
    }

    private fun drawArrow(canvas:Canvas, center:PointF,bearing:Double,len:Float,color:Int,width:Float){
        val a=Math.toRadians(bearing)
        val ex=center.x+sin(a)*len
        val ey=center.y-cos(a)*len
        paint.color=color; paint.strokeWidth=width; paint.style=Paint.Style.STROKE
        canvas.drawLine(center.x,center.y,ex.toFloat(),ey.toFloat(),paint)
        val left=Math.toRadians(bearing+150); val right=Math.toRadians(bearing-150)
        canvas.drawLine(ex.toFloat(),ey.toFloat(),(ex+sin(left)*24).toFloat(),(ey-cos(left)*24).toFloat(),paint)
        canvas.drawLine(ex.toFloat(),ey.toFloat(),(ex+sin(right)*24).toFloat(),(ey-cos(right)*24).toFloat(),paint)
        paint.style=Paint.Style.FILL; canvas.drawCircle(center.x,center.y,7f,paint)
    }

    private fun drawBoat(canvas:Canvas,p:PointF,bearing:Double){
        // Bateau simplifié demandé : arrière plat, côtés légèrement arrondis,
        // coque compacte et proue franchement pointue. Aucun mât ni voile.
        val a=Math.toRadians(bearing)
        val L = 7.0f * scale
        val W = 2.0f * scale
        fun rot(x:Float,y:Float):PointF = PointF(
            p.x+x*cos(a).toFloat()+y*sin(a).toFloat(),
            p.y-x*sin(a).toFloat()+y*cos(a).toFloat()
        )
        val bow=rot(L,0f)
        val sternL=rot(-L*0.70f,-W)
        val sternR=rot(-L*0.70f,W)
        val sideL=rot(-L*0.28f,-W*1.02f)
        val sideR=rot(-L*0.28f,W*1.02f)
        val hull=Path().apply {
            moveTo(bow.x,bow.y)
            quadTo(sideL.x,sideL.y,sternL.x,sternL.y)
            lineTo(sternR.x,sternR.y)
            quadTo(sideR.x,sideR.y,bow.x,bow.y)
            close()
        }
        paint.style=Paint.Style.FILL
        paint.color=Color.rgb(235,240,243)
        canvas.drawPath(hull,paint)
        paint.style=Paint.Style.STROKE
        paint.strokeWidth=max(1.8f,scale*0.20f)
        paint.color=Color.rgb(25,35,43)
        canvas.drawPath(hull,paint)
        // Petit aplat central rouge pour garder une lecture immédiate du bateau.
        val inset=Path().apply {
            moveTo(rot(L*0.72f,0f).x,rot(L*0.72f,0f).y)
            lineTo(rot(-L*0.52f,-W*0.62f).x,rot(-L*0.52f,-W*0.62f).y)
            lineTo(rot(-L*0.52f,W*0.62f).x,rot(-L*0.52f,W*0.62f).y)
            close()
        }
        paint.style=Paint.Style.FILL
        paint.color=Color.rgb(220,45,45)
        canvas.drawPath(inset,paint)
    }
}
