# TopDepartLDtestv1

Projet de test basé sur TopDepartLD v42.

- Vue 2D tactique conservée.
- Nouvelle vue drone tactique simplifiée, accessible par le bouton **2D / 3D**.
- Perspective arrière légèrement surélevée, sans décor ni effets lourds.
- Ligne de départ, vent, quadrillage, trajectoire et TaL conservés.
- Chronomètre de course et temps **DÉPART → LIGNE** conservés.
