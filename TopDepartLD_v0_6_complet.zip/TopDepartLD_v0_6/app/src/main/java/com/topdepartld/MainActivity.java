package com.topdepartld;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.location.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    RaceView view;
    LocationManager lm;
    LocationListener listener;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.WHITE); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); view=new RaceView(this); setContentView(view); startGps(); }
    void startGps(){
        lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        listener=new LocationListener(){ public void onLocationChanged(Location l){ view.setGps(l.getLatitude(),l.getLongitude(),l.getBearing(),l.getSpeed()); } public void onProviderEnabled(String s){} public void onProviderDisabled(String s){} };
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},42); return; }
        try{ lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0.5f,listener); }catch(Exception ignored){}
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==42 && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) startGps(); }

    class RaceView extends View {
        Paint p=new Paint(3); float zoom=1f, ox=0, oy=0; float downX,downY; int mode=0; //0 none, 1 buoy, 2 committee
        float lastDist=-1; double lat=0,lon=0; float bearing=0,speed=0; boolean gps=false; String line="—", wind="—", dtl="—", cap="—", vitesse="—";
        RaceView(Context c){ super(c); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); setBackgroundColor(Color.WHITE); }
        void setGps(double a,double o,float b,float s){lat=a;lon=o;bearing=b;speed=s;gps=true;cap=((int)b+360)%360+"°"; vitesse=String.format(Locale.FRANCE,"%.1f kn",s*1.943844);invalidate();}
        void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align align){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(Typeface.create("sans",Typeface.NORMAL));c.drawText(s,x,y,p);}
        @Override protected void onDraw(Canvas c){super.onDraw(c); int w=getWidth(),h=getHeight();
            float top=70, bottom=72; drawTop(c,w,top); drawGrid(c,w,(int)top,h-(int)bottom); drawBottom(c,w,h,bottom);
        }
        void drawTop(Canvas c,int w,float h){
            p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawRect(0,0,w,h,p);p.setColor(0xffeeeeee);p.setStrokeWidth(1);c.drawLine(0,h,w,h,p);
            int[] xs={0,w/5,w*2/5,w*3/5,w*4/5,w}; String[] labs={"LONGUEUR LIGNE","DIRECTION VENT","DTL","VITESSE","CAP"}; String[] vals={line,wind,dtl,vitesse,cap};
            for(int i=0;i<5;i++){float l=xs[i],r=xs[i+1]; if(i>0){p.setColor(0xffdddddd);c.drawLine(l,8,l,h-8,p);} txt(c,labs[i],(l+r)/2,27,14,0xff444444,Paint.Align.CENTER);txt(c,vals[i],(l+r)/2,53,19,0xff111111,Paint.Align.CENTER);}
        }
        void drawGrid(Canvas c,int w,int h){
            p.setColor(0xffeeeeee);p.setStrokeWidth(1);float step=60*zoom; float startX=(w/2+ox)%step, startY=(h/2+oy)%step;
            for(float x=startX;x<w;x+=step)c.drawLine(x,70,x,h,p); for(float x=startX-step;x>0;x-=step)c.drawLine(x,70,x,h,p);
            for(float y=70+startY%step;y<h;y+=step)c.drawLine(0,y,w,y,p); for(float y=70+startY%step-step;y>70;y-=step)c.drawLine(0,y,w,y,p);
            float bx=w/2+ox, by=(70+h)/2+oy; drawBoat(c,bx,by); if(mode==1) drawMark(c,bx+170*zoom,by-80*zoom,0xffff9800,"B"); if(mode==2) drawMark(c,bx-170*zoom,by+80*zoom,0xffe53935,"C");
            if(gps) drawWind(c,w-180,150); else drawWind(c,w-180,150);
        }
        void drawBoat(Canvas c,float x,float y){Path q=new Path();q.moveTo(x,y-13);q.lineTo(x+30,y);q.lineTo(x,y+13);q.lineTo(x-6,y);q.close();p.setColor(Color.BLACK);p.setStyle(Paint.Style.FILL);c.drawPath(q,p);}
        void drawMark(Canvas c,float x,float y,int col,String s){p.setColor(col);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,13,p);txt(c,s,x,y+6,13,Color.WHITE,Paint.Align.CENTER);}
        void drawWind(Canvas c,float x,float y){p.setColor(0xff2468c4);p.setStrokeWidth(5);p.setStyle(Paint.Style.STROKE);float a=(float)Math.toRadians(-45);float ex=x+(float)Math.cos(a)*55,ey=y+(float)Math.sin(a)*55;c.drawLine(x,y,ex,ey,p);c.drawLine(ex,ey,ex-12,ey+2,p);c.drawLine(ex,ey,ex-3,ey+13,p);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,5,p);}
        void drawBottom(Canvas c,int w,int h,float bh){String[] names={"BOUÉE","COMITÉ","EFFACER","CENTRER","GPS"};int[] cols={0xff1976d2,0xffd32f2f,0xff4a4a4a,0xff2e7d32,0xff607d8b};float gap=5, bw=(w-gap*6)/5f, y=h-bh+4;for(int i=0;i<5;i++){float l=gap+i*(bw+gap);p.setColor(cols[i]);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,y,l+bw,h-4,7,7,p);txt(c,names[i],l+bw/2,y+(bh/2)+6,15,Color.WHITE,Paint.Align.CENTER);}}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            int act=e.getActionMasked(); if(act==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();lastDist=-1;return true;}
            if(act==MotionEvent.ACTION_POINTER_DOWN){if(e.getPointerCount()==2)lastDist=dist(e);return true;}
            if(act==MotionEvent.ACTION_MOVE){if(e.getPointerCount()==2&&lastDist>0){float d=dist(e);zoom*=d/lastDist;zoom=Math.max(.5f,Math.min(3f,zoom));lastDist=d;invalidate();return true;}return true;}
            if(act==MotionEvent.ACTION_UP){if(Math.abs(e.getX()-downX)<20&&Math.abs(e.getY()-downY)<20)click(e.getX(),e.getY());return true;}return true;
        }
        float dist(MotionEvent e){float dx=e.getX(0)-e.getX(1),dy=e.getY(0)-e.getY(1);return (float)Math.hypot(dx,dy);}
        void click(float x,float y){int h=getHeight(),w=getWidth(); if(y<70){int i=Math.min(4,(int)(x/(w/5f))); edit(i);return;} if(y>h-72){int i=(int)(x/(w/5f)); if(i==0)mode=1; else if(i==1)mode=2; else if(i==2){mode=0;line="—";wind="—";dtl="—"; } else if(i==3){ox=oy=0;zoom=1;} else if(i==4)startGps();invalidate();}}
        void edit(final int i){final EditText input=new EditText(MainActivity.this);input.setSingleLine(true);String title=new String[]{"Longueur de ligne","Direction du vent","DTL","Vitesse","Cap"}[i];new AlertDialog.Builder(MainActivity.this).setTitle(title).setView(input).setPositiveButton("OK",(d,w)->{String v=input.getText().toString();if(i==0)line=v;else if(i==1)wind=v;else if(i==2)dtl=v;else if(i==3)vitesse=v;else cap=v;invalidate();}).setNegativeButton("Annuler",null).show();}
    }
}
