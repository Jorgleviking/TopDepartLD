TopDepartLD v0.6

Projet Android Studio complet, interface portrait.
- Canevas blanc sans carte marine, grille Mercator simplifiée.
- Barre supérieure en 5 cases: Longueur ligne, Direction vent, DTL, Vitesse, Cap.
- Boutons bas: Bouée, Comité, Effacer, Centrer, GPS.
- Appui sur une case du haut pour saisir/modifier sa valeur.
- Bouée/Comité placent un repère sur le canevas.
- Effacer retire les repères et valeurs DTL/ligne.
- Centrer remet le zoom à 1 et le bateau au centre.
- Pincement pour zoomer.
- GPS demande la permission de localisation et affiche cap/vitesse quand disponibles.

Ouvrir le dossier TopDepartLD_v0_6 dans Android Studio. Android Studio téléchargera Gradle 8.7 et le plugin Android nécessaires si besoin. JDK 17 recommandé.
