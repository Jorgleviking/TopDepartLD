# TopDepartLD v0.8.2

Première base Android en Kotlin.

Fonctions incluses :
- mode paysage forcé ;
- GPS haute précision ;
- canevas sans fond de carte ;
- projection Web/Mercator pour le rendu ;
- trace GPS historique transparente ;
- mémorisation Bouée et Comité ;
- ligne Bouée-Comité épaisse ;
- 4 demi-droites pointillées, orientées par rapport au Nord : vent ±135°, rouges depuis la Bouée et vertes depuis le Comité ;
- flèche de vent visible ;
- triangle allongé pour le bateau, orienté par le cap GPS ;
- longueur de ligne ;
- DTL en mètres et en longueurs de 11 m ;
- compte à rebours 5:00 ;
- annonces vocales en français aux échéances demandées ;
- boutons Bouée, Comité, Effacer, Centrer.

À compléter dans la prochaine itération :
- comparaison DTL / temps restant avec couleur rouge-jaune-verte synchronisée avec le compte à rebours ;
- persistance éventuelle des marques ;
- réglage de longueur des demi-droites et de l'échelle du canevas ;
- test terrain et ajustement UX.


## v0.8.2 — barre supérieure refondue
- barre supérieure en vraies cases visuelles : LONGUEUR LIGNE / DIRECTION VENT / VITESSE-CAP / DTL ;
- valeurs centrées et largeur adaptative ;
- aucun chevauchement sur les écrans paysage ;
- dimensions UI exprimées en dp ;
- prise en compte des barres système Android en paysage ;
- boutons inférieurs adaptatifs avec libellés visibles ;
- nom/version de l’application incrémentés à TopDepartLD v0.7.
