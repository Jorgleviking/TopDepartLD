package fr.nauticalstart.app

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.*
import java.util.Locale
import kotlin.math.*

data class Geo(val lat: Double, val lon: Double)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var board: NavView
    private lateinit var fused: FusedLocationProviderClient
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 20, 29))
        }

        // Android 15/targetSdk 35 can draw behind system bars. Keep the UI
        // inside the usable area so the right-side navigation bar never
        // covers controls on landscape phones.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

        fun label(text: String, size: Float = 15f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(Color.DKGRAY)
                gravity = Gravity.CENTER
                maxLines = 2
                includeFontPadding = true
            }

        // v0.8 — barre supérieure dessinée comme une vraie rangée de cases.
        // Chaque case prend une largeur proportionnelle : aucun texte ne peut
        // déborder ou se superposer, même sur un téléphone différent.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }

        fun boxBackground(): android.graphics.drawable.GradientDrawable =
            android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(10, 25, 35))
                setStroke(dp(1), Color.rgb(55, 70, 78))
                cornerRadius = dp(5).toFloat()
            }

        fun valueLabel(text: String, size: Float = 17f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(Color.rgb(235, 240, 243))
                gravity = Gravity.CENTER
                maxLines = 1
                includeFontPadding = false
                typeface = Typeface.DEFAULT_BOLD
                ellipsize = android.text.TextUtils.TruncateAt.END
            }

        fun titleLabel(text: String): TextView =
            TextView(this).apply {
                this.text = text
                textSize = 12f
                setTextColor(Color.rgb(190, 202, 208))
                gravity = Gravity.CENTER
                maxLines = 1
                includeFontPadding = false
                typeface = Typeface.DEFAULT
            }

        fun makeCell(weight: Float, content: View): View {
            val frame = FrameLayout(this).apply {
                background = boxBackground()
                addView(content, FrameLayout.LayoutParams(-1, -1))
            }
            top.addView(frame, LinearLayout.LayoutParams(0, dp(58), weight).apply {
                leftMargin = dp(2)
                rightMargin = dp(2)
            })
            return frame
        }

        fun makeStack(title: String, value: String): LinearLayout =
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(2), dp(3), dp(2))
                addView(titleLabel(title), LinearLayout.LayoutParams(-1, 0, 0.8f))
                addView(valueLabel(value), LinearLayout.LayoutParams(-1, 0, 1.2f))
            }

        val windInput = EditText(this).apply {
            hint = "000"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            textSize = 18f
            gravity = Gravity.CENTER
            setOnFocusChangeListener { v, hasFocus -> if (hasFocus) (v as EditText).selectAll() }
            setTextColor(Color.rgb(240, 245, 247))
            setHintTextColor(Color.rgb(110, 125, 132))
            setPadding(0, 0, 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
        }
        val windCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(2), dp(3), dp(2))
            addView(titleLabel("DIRECTION VENT"), LinearLayout.LayoutParams(-1, 0, 0.8f))
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.addView(windInput, LinearLayout.LayoutParams(dp(78), -1))
            row.addView(valueLabel("°", 18f), LinearLayout.LayoutParams(dp(22), -1))
            addView(row, LinearLayout.LayoutParams(-1, 0, 1.2f))
        }
        makeCell(1.00f, windCell)

        val speed = valueLabel("— kn", 16f)
        val heading = valueLabel("—°", 16f)
        val speedHeadingCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(2), dp(3), dp(2))
            addView(titleLabel("VITESSE / CAP"), LinearLayout.LayoutParams(-1, 0, 0.8f))
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                addView(speed, LinearLayout.LayoutParams(0, -1, 1f))
                addView(valueLabel("  |  ", 13f), LinearLayout.LayoutParams(dp(34), -1))
                addView(heading, LinearLayout.LayoutParams(0, -1, 1f))
            }
            addView(row, LinearLayout.LayoutParams(-1, 0, 1.2f))
        }
        makeCell(1.20f, speedHeadingCell)

        val dtl = valueLabel("— m  /  — L", 15f).apply {
            typeface = Typeface.DEFAULT_BOLD
        }
        val dtlCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(2), dp(3), dp(2))
            addView(titleLabel("LaL"), LinearLayout.LayoutParams(-1, 0, 0.8f))
            addView(dtl, LinearLayout.LayoutParams(-1, 0, 1.2f))
        }
        makeCell(0.90f, dtlCell)

        // Temps à la ligne + compte à rebours avec 3 commandes.
        val timeToLine = valueLabel("— s", 18f).apply {
            setTextColor(Color.rgb(235, 240, 243))
        }
        val timeCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(2), dp(3), dp(2))
            addView(titleLabel("TaL"), LinearLayout.LayoutParams(-1, 0, 0.8f))
            addView(timeToLine, LinearLayout.LayoutParams(-1, 0, 1.2f))
        }
        makeCell(0.85f, timeCell)

        val timer = valueLabel("05:00", 28f).apply {
            setTextColor(Color.RED)
        }
        val timerCell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = boxBackground()
            addView(timer, LinearLayout.LayoutParams(0, -1, 1.35f))
        }

        val start = Button(this).apply {
            text = "▶"
            textSize = 16f
            setTextColor(Color.WHITE)
            background = ColorDrawable(Color.rgb(22, 45, 53))
            contentDescription = "Démarrer le compte à rebours"
            minWidth = 0; minimumWidth = 0
            setPadding(0, 0, 0, 0)
        }
        val stop = Button(this).apply {
            text = "■"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = ColorDrawable(Color.rgb(45, 35, 38))
            contentDescription = "Arrêter le compte à rebours"
            minWidth = 0; minimumWidth = 0
            setPadding(0, 0, 0, 0)
        }
        val reset = Button(this).apply {
            text = "↻"
            textSize = 18f
            setTextColor(Color.WHITE)
            background = ColorDrawable(Color.rgb(35, 45, 50))
            contentDescription = "Remettre le compte à rebours à zéro"
            minWidth = 0; minimumWidth = 0
            setPadding(0, 0, 0, 0)
        }
        timerCell.addView(start, LinearLayout.LayoutParams(dp(34), dp(40)).apply { leftMargin = dp(1) })
        timerCell.addView(stop, LinearLayout.LayoutParams(dp(34), dp(40)).apply { leftMargin = dp(1) })
        timerCell.addView(reset, LinearLayout.LayoutParams(dp(34), dp(40)).apply { leftMargin = dp(1); rightMargin = dp(1) })
        top.addView(timerCell, LinearLayout.LayoutParams(0, dp(58), 1.55f).apply {
            leftMargin = dp(2); rightMargin = dp(2)
        })

        root.addView(top, LinearLayout.LayoutParams(-1, dp(62)))

        board = NavView(this) { /* longueur de ligne affichée directement sur le canevas */ }
        board.windProvider = { windInput.text.toString().toDoubleOrNull()?.mod(360.0) ?: 0.0 }
        board.statusProvider = { d, n, col ->
            dtl.text = if (d >= 0) "%.1f m / %.1f L".format(d, d / 11.0) else "— m / — L"
            dtl.setTextColor(Color.rgb(235, 240, 243))
            val seconds = if (d >= 0 && board.lastSpeed > 0.3) (d / (board.lastSpeed * 0.514444)).roundToInt() else -1
            timeToLine.text = if (seconds >= 0) "${seconds} s" else "— s"
            val delta = if (seconds >= 0) seconds - board.countdownSeconds else Int.MIN_VALUE
            timeToLine.setTextColor(when {
                seconds < 0 -> Color.rgb(235, 240, 243)
                seconds < board.countdownSeconds -> Color.RED
                delta < 2 -> Color.rgb(255, 165, 0)
                else -> Color.rgb(70, 210, 90)
            })
        }
        board.speedProvider = { s -> speed.text = "%.1f kn".format(s) }
        board.headingProvider = { h -> heading.text = "%03d°".format(((h % 360 + 360) % 360).roundToInt()) }

        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        fun action(text: String, color: Int, textSizeSp: Float, onClick: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                setTextColor(Color.WHITE)
                background = ColorDrawable(color)
                setOnClickListener { onClick() }
                textSize = textSizeSp
                minWidth = 0; minimumWidth = 0
                maxLines = 1
                isAllCaps = false
                setPadding(dp(1), 0, dp(1), 0)
                includeFontPadding = false
            }
        bottom.addView(action("BOUÉE", Color.rgb(21,101,192), 13f) { board.saveBuoy() },
            LinearLayout.LayoutParams(0, dp(35), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("COMITÉ", Color.rgb(198,40,40), 13f) { board.saveCommittee() },
            LinearLayout.LayoutParams(0, dp(35), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("EFFACER BOUÉE", Color.DKGRAY, 10.5f) { board.clearBuoy() },
            LinearLayout.LayoutParams(0, dp(35), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        bottom.addView(action("EFFACER COMITÉ", Color.DKGRAY, 10.5f) { board.clearCommittee() },
            LinearLayout.LayoutParams(0, dp(35), 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(43)))

        setContentView(root)

        var remaining = 300
        var running = false
        start.setOnClickListener { running = true }
        stop.setOnClickListener { running = false }
        reset.setOnClickListener { remaining = 300; board.countdownSeconds = 300; running = false; timer.text = "05:00"; board.invalidate() }

        val handler = android.os.Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                if (running && remaining > 0) {
                    remaining--
                    board.countdownSeconds = remaining
                    val mm = remaining / 60
                    val ss = remaining % 60
                    timer.text = "%02d:%02d".format(mm, ss)
                    when {
                        remaining > 60 && ss == 0 -> speak("$mm minutes")
                        remaining in 10..60 && remaining % 10 == 0 -> speak(
                            if (remaining == 60) "1 minute" else "$remaining secondes"
                        )
                        remaining in 1..9 -> speak("$remaining")
                        remaining == 0 -> speak("Départ")
                    }
                }
                handler.postDelayed(this, 1000)
            }
        }
        handler.postDelayed(tick, 1000)

        fused = LocationServices.getFusedLocationProviderClient(this)
        requestLocation()
    }

    private fun requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 42
            )
            return
        }
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000)
            .setMinUpdateIntervalMillis(500)
            .setMaxUpdateDelayMillis(1500)
            .build()
        fused.requestLocationUpdates(request, object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc ->
                    board.updateLocation(
                        Geo(loc.latitude, loc.longitude),
                        if (loc.hasBearing()) loc.bearing.toDouble() else board.lastHeading,
                        if (loc.hasSpeed()) loc.speed * 1.94384449 else board.lastSpeed
                    )
                }
            }
        }, Looper.getMainLooper())
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        if (r == 42) requestLocation()
    }

    private fun speak(s: String) {
        tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "countdown")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.FRENCH
        }
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}

class NavView(
    context: android.content.Context,
    private val onLineLength: (Double) -> Unit
) : View(context) {

    var windProvider: () -> Double = { 0.0 }
    var statusProvider: (Double, Double, Int) -> Unit = { _,_,_ -> }
    var speedProvider: (Double) -> Unit = {}
    var headingProvider: (Double) -> Unit = {}

    var lastHeading = 0.0
    var lastSpeed = 0.0
    private var boat: Geo? = null
    private val trail = mutableListOf<Geo>()
    private var buoy: Geo? = null
    private var committee: Geo? = null
    private var center: Geo? = null
    private var lineLengthMeters: Double = -1.0
    // Current race countdown, in seconds, shared with the TaL color logic.
    var countdownSeconds: Int = 300

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private var scale = 1.8f // pixels per metre at zoom 1.0

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isFocusable = true
    }

    fun updateLocation(g: Geo, heading: Double, speed: Double) {
        boat = g; lastHeading = heading; lastSpeed = speed
        if (trail.isEmpty() || haversine(trail.last(), g) > 1.5) trail.add(g)
        if (center == null) center = g
        speedProvider(speed); headingProvider(heading)
        invalidate()
    }

    fun saveBuoy() { boat?.let { buoy = it; if (center == null) center = it; invalidate(); reportLine() } }
    fun saveCommittee() { boat?.let { committee = it; if (center == null) center = it; invalidate(); reportLine() } }
    fun clearBuoy() { buoy = null; invalidate(); reportLine() }
    fun clearCommittee() { committee = null; invalidate(); reportLine() }
    fun clearMarks() { buoy = null; committee = null; invalidate(); reportLine() }
    fun centerOnBoat() { center = boat; invalidate() }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_UP && event.pointerCount == 1) {
            val x = event.x; val y = event.y
            if (x in 18f..100f && y in 82f..142f) { scale = (scale * 1.35f).coerceAtMost(12f); invalidate(); return true }
            if (x in 18f..100f && y in 147f..207f) { scale = (scale / 1.35f).coerceAtLeast(0.45f); invalidate(); return true }
        }
        if (event.pointerCount >= 2) {
            when (event.actionMasked) {
                MotionEvent.ACTION_POINTER_DOWN -> {
                    pinchStartDistance = distance(event)
                    pinchStartScale = scale
                }
                MotionEvent.ACTION_MOVE -> {
                    val d = distance(event)
                    if (pinchStartDistance > 0f) {
                        scale = (pinchStartScale * (d / pinchStartDistance)).coerceIn(0.45f, 12f)
                        invalidate()
                    }
                }
            }
            return true
        }
        return true
    }

    private var pinchStartDistance = 0f
    private var pinchStartScale = 1.8f

    private fun distance(e: MotionEvent): Float {
        if (e.pointerCount < 2) return 0f
        val dx = e.getX(0) - e.getX(1)
        val dy = e.getY(0) - e.getY(1)
        return hypot(dx, dy)
    }


    private fun reportLine() {
        val d = if (buoy != null && committee != null) haversine(buoy!!, committee!!) else -1.0
        lineLengthMeters = d
        onLineLength(d)
        invalidate()
    }

    private fun haversine(a: Geo, b: Geo): Double {
        val R = 6371000.0
        val p1 = Math.toRadians(a.lat); val p2 = Math.toRadians(b.lat)
        val dp = Math.toRadians(b.lat-a.lat); val dl = Math.toRadians(b.lon-a.lon)
        val x = sin(dp/2).pow(2) + cos(p1)*cos(p2)*sin(dl/2).pow(2)
        return 2*R*atan2(sqrt(x), sqrt(1-x))
    }

    // Cap géographique de la ligne comité -> bouée.
    // Sert uniquement à orienter l'affichage pour que la ligne de départ
    // soit horizontale dès que les deux marques sont enregistrées.
    private fun bearingBetween(a: Geo, b: Geo): Double {
        val lat1 = Math.toRadians(a.lat)
        val lat2 = Math.toRadians(b.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    // Web-Mercator screen coordinates around the chosen center.
    private fun project(g: Geo, c: Geo): PointF {
        val R = 6378137.0
        val x = R * Math.toRadians(g.lon)
        val y = R * ln(tan(Math.PI/4 + Math.toRadians(g.lat)/2))
        val cx = R * Math.toRadians(c.lon)
        val cy = R * ln(tan(Math.PI/4 + Math.toRadians(c.lat)/2))
        val pixelsPerMeter = max(scale, 0.000001f)
        return PointF(
            (width/2f + ((x-cx)*pixelsPerMeter)).toFloat(),
            (height/2f - ((y-cy)*pixelsPerMeter)).toFloat()
        )
    }

    private fun bearingPoint(g: Geo, bearingDeg: Double, distanceM: Double): Geo {
        val R = 6371000.0
        val br = Math.toRadians((bearingDeg % 360 + 360) % 360)
        val lat1 = Math.toRadians(g.lat)
        val lon1 = Math.toRadians(g.lon)
        val d = distanceM / R
        val lat2 = asin(sin(lat1)*cos(d) + cos(lat1)*sin(d)*cos(br))
        val lon2 = lon1 + atan2(sin(br)*sin(d)*cos(lat1), cos(d)-sin(lat1)*sin(lat2))
        return Geo(Math.toDegrees(lat2), Math.toDegrees(lon2))
    }

    private fun destinationLine(start: Geo, bearing: Double, length: Double, c: Geo): Path {
        val end = bearingPoint(start, bearing, length)
        val p1 = project(start, c); val p2 = project(end, c)
        return Path().apply { moveTo(p1.x,p1.y); lineTo(p2.x,p2.y) }
    }

    private fun forwardDistanceToLine(boat: Geo, a: Geo, b: Geo, heading: Double): Double {
        // Local tangent plane (east, north). We only report the distance
        // when the boat's heading ray intersects the race line segment A-B
        // somewhere IN FRONT of the boat. Otherwise no distance is shown.
        val lat0 = Math.toRadians((a.lat + b.lat + boat.lat) / 3.0)
        fun xy(g: Geo): DoubleArray {
            val east = Math.toRadians(g.lon - boat.lon) * 6371000.0 * cos(lat0)
            val north = Math.toRadians(g.lat - boat.lat) * 6371000.0
            return doubleArrayOf(east, north)
        }
        val p = doubleArrayOf(0.0, 0.0)
        val q = xy(a)
        val r = xy(b)
        val hx = sin(Math.toRadians(heading))
        val hy = cos(Math.toRadians(heading))
        val dx = r[0] - q[0]
        val dy = r[1] - q[1]
        val cross = hx * dy - hy * dx
        if (abs(cross) < 1e-9) return -1.0
        val qx = q[0]; val qy = q[1]
        val t = (qx * dy - qy * dx) / cross
        val u = (qx * hy - qy * hx) / cross
        return if (t >= 0.0 && u in 0.0..1.0) t else -1.0
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(7, 20, 29))
        val c = center ?: boat ?: Geo(0.0,0.0)
        val windFrom = windProvider().mod(360.0)
        // Avant le placement des deux marques, l'affichage reste référencé
        // par le vent. Dès que comité + bouée sont présents, la ligne de départ
        // devient la nouvelle référence visuelle et est automatiquement
        // horizontale à l'écran.
        //
        // Pour une ligne de relèvement "bearing", une rotation de
        // bearing - 90° la rend horizontale.
        val displayRotation = if (buoy != null && committee != null) {
            (bearingBetween(committee!!, buoy!!) - 90.0).toFloat()
        } else {
            (-windFrom).toFloat()
        }

        canvas.save()
        canvas.rotate(displayRotation, width / 2f, height / 2f)

        // Référence d'affichage : le vent est TOUJOURS l'axe vertical.
        // La carte entière est donc tournée de -vent, de sorte que le vent
        // entrant ("vient de là") corresponde à la verticale de l'écran.
        //
        // Le quadrillage est ensuite incliné de 45° par rapport à cet axe
        // vertical du vent. Il remplit volontairement largement les quatre
        // coins afin qu'aucune zone vide n'apparaisse après rotation.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = Color.rgb(42, 62, 72)
        // One small grid square = representative boat length (10 m).
        val grid = 11f * scale
        val diagonal = hypot(width.toFloat(), height.toFloat()) + grid * 2f

        canvas.save()
        canvas.rotate(45f, width / 2f, height / 2f)
        var x = -diagonal
        while (x <= diagonal) {
            canvas.drawLine(x, -diagonal, x, diagonal, paint)
            x += grid
        }
        var y = -diagonal
        while (y <= diagonal) {
            canvas.drawLine(-diagonal, y, diagonal, y, paint)
            y += grid
        }
        canvas.restore()

        // Historical GPS trail, deliberately behind everything else.
        if(trail.size>1) {
            paint.color=0x40555555; paint.strokeWidth=5f; paint.style=Paint.Style.STROKE
            val path=Path()
            trail.forEachIndexed { i,g -> val p=project(g,c); if(i==0) path.moveTo(p.x,p.y) else path.lineTo(p.x,p.y) }
            canvas.drawPath(path,paint)
        }

        // La ligne comité-bouée est maintenant horizontale à l'écran dès que
        // les deux marques sont sélectionnées. Les laylines restent calculées
        // à partir de la direction du vent.
        if(buoy!=null && committee!=null) {
            val b=project(buoy!!,c); val co=project(committee!!,c)
            paint.color=Color.BLACK; paint.strokeWidth=9f; paint.style=Paint.Style.STROKE
            canvas.drawLine(b.x,b.y,co.x,co.y,paint)

            drawRay(canvas, buoy!!, windFrom+135, Color.RED, c)
            drawRay(canvas, buoy!!, windFrom-135, Color.RED, c)
            drawRay(canvas, committee!!, windFrom+135, Color.rgb(46,125,50), c)
            drawRay(canvas, committee!!, windFrom-135, Color.rgb(46,125,50), c)
        }

        // Points.
        buoy?.let { drawPoint(canvas, project(it,c), Color.rgb(21,101,192), "BOUÉE") }
        committee?.let { drawPoint(canvas, project(it,c), Color.rgb(198,40,40), "COMITÉ") }

        // Boat: elongated triangle, pointed along GPS heading.
        boat?.let {
            val p=project(it,c)
            drawBoat(canvas,p,lastHeading)
            val d=if(buoy!=null&&committee!=null) forwardDistanceToLine(it,buoy!!,committee!!,lastHeading) else -1.0
            val lengths=if(d>=0) d/11.0 else -1.0
            val timeToLine=if(d>=0 && lastSpeed>0.3) d/(lastSpeed*0.514444) else Double.POSITIVE_INFINITY
            val col=when {
                !timeToLine.isFinite() -> Color.DKGRAY
                timeToLine < countdownSeconds -> Color.RED
                timeToLine - countdownSeconds < 2.0 -> Color.rgb(255,165,0)
                else -> Color.rgb(46,125,50)
            }
            statusProvider(d,lengths,col)
        }

        canvas.restore()

        // Dans cette vue, la verticale de l'écran EST la référence du vent.
        // La flèche reste donc toujours verticale et pointe vers le bas :
        // elle représente le déplacement du vent qui vient de la direction
        // saisie. Quand la valeur du vent change, la carte tourne avec elle,
        // pas la flèche.
        val wc = PointF(width / 2f, 78f)
        drawArrow(canvas, wc, 180.0, 72f, Color.WHITE, 5f)

        // Fixed screen labels and zoom controls stay upright.
        paint.style=Paint.Style.FILL; paint.color=Color.rgb(235,240,243); paint.textSize=16f
        canvas.drawText("Vent %.0f°".format(windFrom), 24f, 28f, paint)
        paint.textSize=11f; paint.color=Color.rgb(175,190,197)
        canvas.drawText("(vient de là)", 24f, 44f, paint)
        val lineText = if (lineLengthMeters >= 0) {
            "Ligne %.0f m  /  %.2f NM".format(lineLengthMeters, lineLengthMeters / 1852.0)
        } else "Ligne —"
        canvas.drawText(lineText, 24f, 61f, paint)

        // Metric scale bar: always represents exactly 100 real metres.
        val barPx = (100f * scale).coerceIn(80f, width * 0.28f)
        paint.color=Color.rgb(230,235,238); paint.strokeWidth=2f; paint.style=Paint.Style.STROKE
        canvas.drawLine(width-barPx-28f, height-32f, width-28f, height-32f, paint)
        canvas.drawLine(width-barPx-28f, height-38f, width-barPx-28f, height-26f, paint)
        canvas.drawLine(width-28f, height-38f, width-28f, height-26f, paint)
        paint.style=Paint.Style.FILL; paint.textSize=14f
        canvas.drawText("100 m", width-barPx/2f-20f, height-44f, paint)

        // Boutons de zoom + / −
        paint.style = Paint.Style.FILL; paint.color = Color.rgb(12, 29, 39)
        canvas.drawRoundRect(18f, 82f, 100f, 142f, 12f, 12f, paint)
        canvas.drawRoundRect(18f, 147f, 100f, 207f, 12f, 12f, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = Color.rgb(70, 90, 100)
        canvas.drawRoundRect(18f, 82f, 100f, 142f, 12f, 12f, paint)
        canvas.drawRoundRect(18f, 147f, 100f, 207f, 12f, 12f, paint)
        paint.style = Paint.Style.FILL; paint.color = Color.WHITE; paint.textSize = 42f
        canvas.drawText("+", 42f, 126f, paint)
        canvas.drawText("−", 43f, 191f, paint)
    }

    private fun drawRay(canvas: Canvas, start: Geo, bearing: Double, color: Int, c: Geo) {
        paint.color=color; paint.strokeWidth=4f; paint.style=Paint.Style.STROKE
        paint.pathEffect=DashPathEffect(floatArrayOf(16f,12f),0f)
        canvas.drawPath(destinationLine(start,bearing,3000.0,c),paint)
        paint.pathEffect=null
    }

    private fun drawPoint(canvas: Canvas,p:PointF,color:Int,text:String){
        paint.style=Paint.Style.FILL; paint.color=color; canvas.drawCircle(p.x,p.y,14f,paint)
        paint.color=Color.DKGRAY; paint.textSize=18f; canvas.drawText(text,p.x+20,p.y+6,paint)
    }

    private fun drawArrow(canvas:Canvas, center:PointF,bearing:Double,len:Float,color:Int,width:Float){
        val a=Math.toRadians(bearing)
        val ex=center.x+sin(a)*len
        val ey=center.y-cos(a)*len
        paint.color=color; paint.strokeWidth=width; paint.style=Paint.Style.STROKE
        canvas.drawLine(center.x,center.y,ex.toFloat(),ey.toFloat(),paint)
        val left=Math.toRadians(bearing+150); val right=Math.toRadians(bearing-150)
        canvas.drawLine(ex.toFloat(),ey.toFloat(),(ex+sin(left)*24).toFloat(),(ey-cos(left)*24).toFloat(),paint)
        canvas.drawLine(ex.toFloat(),ey.toFloat(),(ex+sin(right)*24).toFloat(),(ey-cos(right)*24).toFloat(),paint)
        paint.style=Paint.Style.FILL; canvas.drawCircle(center.x,center.y,7f,paint)
    }

    private fun drawBoat(canvas:Canvas,p:PointF,bearing:Double){
        // Representative racing boat length = 10 m, width = 3 m.
        // Its displayed size therefore follows the same real-world scale as
        // the metric grid and zoom.
        val a=Math.toRadians(bearing)
        val halfLength = 5.5f * scale
        val halfWidth = 1.5f * scale
        fun rot(x:Float,y:Float):PointF =
            PointF((p.x+x*cos(a).toFloat()+y*sin(a).toFloat()),
                   (p.y-x*sin(a).toFloat()+y*cos(a).toFloat()))
        val tip=rot(halfLength,0f)
        val l=rot(-halfLength,-halfWidth)
        val r=rot(-halfLength,halfWidth)
        val path=Path().apply{moveTo(tip.x,tip.y);lineTo(l.x,l.y);lineTo(r.x,r.y);close()}
        paint.style=Paint.Style.FILL; paint.color=Color.rgb(225,232,235); canvas.drawPath(path,paint)
        paint.style=Paint.Style.STROKE; paint.strokeWidth=max(1.5f,scale*0.18f); paint.color=Color.WHITE
        canvas.drawPath(path,paint)
    }
}
